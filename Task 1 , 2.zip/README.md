# CadetX — Product Launch Analytics Project

**Genre:** AI Writing Tools
**Products:** Jasper, Copy.ai, Writesonic, Rytr
**Mode:** Solo (all four specialist roles covered by one person)

## Repository structure
```
/data/raw          real, cited raw signal dataset (Task 2)
/data/cleaned       cleaned/normalized data (Task 3+)
/data/processed     feature-engineered data (Task 5+)
/notebooks          analysis notebooks (Task 4+)
/src                data-collection & processing scripts
/visualizations     exported charts/figures (Task 4+)
/reports            EDA reports, final report (Task 4, 9)
/presentation       final slide deck (Task 9)
/docs               project plan, data source log, methodology notes
```

## Batch progress
- [x] Task 1 — Project Planning & Product Selection
- [x] Task 2 — External Data Collection (Social Signals)
- [ ] Task 3 — Data Cleaning & Text Preprocessing
- [ ] Task 4 — Exploratory Data Analysis
- [ ] Task 5 — Feature Engineering
- [ ] Task 6 — Prediction Model
- [ ] Task 7 — Cross-Product Comparison
- [ ] Task 8 — Unified Genre-Level Success Framework
- [ ] Task 9 — Final Report, Documentation & Presentation
- [ ] Task 10 — Final Submission, Review & Reflection

## Note on the CadetX evaluation rubric (solo submission)

CadetX's evaluation criteria are written for a 4-person team working over three
months with a rotating Scrum and a mentor. This submission is solo, completed
in a single working session, so two rubric criteria need an explicit note
rather than a silent checkbox:

- **Collaboration** ("active participation in the weekly Scrum and the
  rotating roles") — does not apply to a solo submission. There is no team
  and no mentor in this workflow, and I have not fabricated meeting minutes,
  Scrum notes, or teammate contributions to simulate one. If this project is
  evaluated against the team rubric as-is, this criterion should be read as
  "not applicable" rather than "unmet."
- **Consistency** ("regular submissions... throughout the three months") —
  also does not map onto a single-session solo build. The equivalent I can
  offer is: each of the 10 tasks was (and will be) completed as a discrete,
  validated batch rather than rushed together, with an explicit stop/review
  point after every two tasks — see Batch Progress below.

The remaining criteria — **specialist depth, quality, documentation,
completeness** — do apply to a solo submission and are being tracked
honestly against the actual work produced so far, not assumed complete.
Current honest status after Tasks 1-2: documentation is in place; specialist
depth is a first pass (deepens in Task 7); quality (models/EDA/visuals) is
not yet applicable, since no modelling or EDA work exists yet; completeness
is 2 of 10 tasks.

## Data integrity note
All collected data traces to real, publicly accessible URLs opened during
collection (G2, Capterra, Trustpilot, Gartner Peer Insights, and independent
editorial reviews) — see `docs/cadetx_task02_data-source-log_v01.md` for full
methodology, source list, and documented limitations (no Twitter/X, Reddit,
LinkedIn or YouTube API access was available in this environment; no data
was fabricated to fill that gap).
