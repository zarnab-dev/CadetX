"""
CadetX Task 02 — builds the raw social/market-signal dataset from real,
web-search-sourced observations (no fabricated data). Every row traces to a
real, citable public URL that was retrieved during this session.
"""
import csv

rows = [
# signal_id, product, platform, source_type, date_observed, author_or_handle,
# text_summary (paraphrased, not verbatim), metric_name, metric_value, url, access_date

# ---------------- JASPER ----------------
["cadetx_j001","Jasper","G2","aggregate_rating","2026 (live)","G2 aggregate",
 "Aggregate rating and review volume for Jasper on G2's AI Writing Assistant category.",
 "avg_rating|review_count","4.7|1269","https://www.g2.com/products/jasper-ai/reviews","2026-09-08"],
["cadetx_j002","Jasper","G2","individual_review","2026-01-16","Nabin P. (CEO, Mid-Market)",
 "Reviewer praises Jasper's content-generation speed, tone consistency, template flexibility, SEO-tool integration, and easy setup.",
 "review_rating","not stated (qualitative)","https://www.g2.com/sellers/jasper","2026-09-08"],
["cadetx_j003","Jasper","G2 Discussions","discussion_thread","undated","rada c. (Self-Employed)",
 "Discussion thread asking whether Jasper will add creative/fiction-writing features; drew community replies.",
 "upvotes|comments","0|6","https://www.g2.com/products/jasper-ai/discuss","2026-09-08"],
["cadetx_j004","Jasper","G2 Discussions","discussion_thread","undated","Zain U.",
 "Discussion thread raising concerns about factual accuracy of Jasper output on technical topics.",
 "upvotes|comments","0|1","https://www.g2.com/products/jasper-ai/discuss","2026-09-08"],
["cadetx_j005","Jasper","Capterra","review_sample","2021-05 to 2023-09","multiple reviewers (sampled pages 13/27/30)",
 "Sampled reviews show recurring praise for speed/quality of output and recurring complaints about credit consumption and pricing.",
 "rating_range","4.0-5.0","https://www.capterra.com/p/217242/Jasper/reviews","2026-09-08"],
["cadetx_j006","Jasper","TechRadar (editorial)","editorial_review","undated","TechRadar staff",
 "Editorial review verdict: powerful features but a steep learning curve; pros include accurate plagiarism checking and wide language support, cons include pricing and inconsistent content quality.",
 "editorial_verdict","mixed-positive","https://www.techradar.com/reviews/jasper-ai","2026-09-08"],
["cadetx_j007","Jasper","Substack newsletter (industry press)","press_mention","2026 (recent)","YC Generative AI Pulse",
 "Industry newsletter reports Jasper launched a Marketing Workflow Automation suite with an AI App Library of 80+ marketing apps.",
 "product_momentum_signal","launch_announced","https://generativeaipulse.substack.com/p/yc-generative-ai-pulse-3","2026-09-08"],
["cadetx_j008","Jasper","G2 (comparison)","comparative_signal","2026 (live)","G2 aggregate",
 "Head-to-head G2 comparison data: reviewers rate Jasper ahead of Writesonic on usability and requirement-fit dimensions, behind on time-to-ROI.",
 "comparative_rating","mixed","https://g2.com/products/jasper-ai/competitors/alternatives","2026-09-08"],
["cadetx_j009","Jasper","eesel AI (industry roundup)","editorial_review","2026-06-10","eesel AI",
 "2026 8-platform head-to-head names Jasper the pick for teams wanting brand voice, campaigns and image generation in one tool; cites 4.7/5 across 1,270 G2 reviews at $59-69/seat/month.",
 "editorial_rank","top_pick_marketing_teams","https://www.eesel.ai/blog/ai-writing-tools-comparison","2026-09-08"],

# ---------------- COPY.AI ----------------
["cadetx_c001","Copy.ai","G2 (via SearchAtlas review)","aggregate_rating","2026-05-25","SearchAtlas editorial",
 "Third-party review site reports Copy.ai scoring 4.9/5 on G2 with a 9.6/10 ease-of-use score, strongest for short-form marketing copy.",
 "avg_rating|ease_of_use","4.9|9.6","https://searchatlas.com/blog/copy-ai-review/","2026-09-08"],
["cadetx_c002","Copy.ai","copy.ai official reviews page","testimonial","undated","Monica O. (Freelance Content Writer)",
 "Testimonial praises Copy.ai's easy interface, useful templates, and output quality relative to other AI writing tools she has used.",
 "review_rating","4.9 (site-reported)","https://www.copy.ai/reviews","2026-09-08"],
["cadetx_c003","Copy.ai","Gartner Peer Insights","review_sample","2026 (live)","Gartner reviewers",
 "Reviewers value Copy.ai's GTM workflow automation and short-form content quality; a recurring complaint is limited ability to edit AI output directly.",
 "sentiment","mixed-positive","https://www.gartner.com/reviews/market/generative-ai-knowledge-management-apps-general-productivity/vendor/copy-ai/product/copy-ai","2026-09-08"],
["cadetx_c004","Copy.ai","AIToolShop (industry roundup)","editorial_review","2026-04-23","AIToolShop",
 "Roundup reports 3,000+ G2 reviews at a 4.8 rating and cites analysis of 3,400+ verified reviews across G2 and Capterra combined.",
 "review_count|avg_rating","3000+|4.8","https://aitoolshop.co/reviews/copyai-review/","2026-09-08"],
["cadetx_c005","Copy.ai","AgenticCMO (industry roundup)","editorial_review","2025-12-02","AgenticCMO",
 "Roundup flags a ratings gap between G2/Capterra (higher, some incentivized submissions) and Trustpilot (lower, more unfiltered billing/support complaints).",
 "cross_platform_rating_gap","flagged","https://www.agenticcmo.org/copy-ai-review-roundup-2025/","2026-09-08"],
["cadetx_c006","Copy.ai","G2 category page","aggregate_rating","2026 (live)","G2 aggregate",
 "G2's AI Content Creation Platforms category (includes Copy.ai) shows 25,014 verified category-wide reviews as of this pull.",
 "category_review_count","25014","https://www.g2.com/products/copy-ai/reviews?page=2","2026-09-08"],
["cadetx_c007","Copy.ai","Juma (editorial review)","review_quote","undated","Juma editorial (citing a G2 reviewer)",
 "A cited G2 reviewer reports being 'highly underwhelmed' after running out of credits quickly.",
 "sentiment","negative","https://juma.ai/blog/copy-ai-review","2026-09-08"],
["cadetx_c008","Copy.ai","G2 (head-to-head vs Writesonic)","comparative_signal","2026 (live)","G2 aggregate",
 "G2 compare page shows Copy.ai at 182 reviews / 4.7 rating in this specific comparison view — lower than other sources' 4.8-4.9 figures, indicating rating figures vary by snapshot/page.",
 "avg_rating|review_count","4.7|182","https://g2.com/compare/copy-ai-vs-writesonic","2026-09-08"],

# ---------------- WRITESONIC ----------------
["cadetx_w001","Writesonic","G2 (head-to-head vs Copy.ai)","aggregate_rating","2026 (live)","G2 aggregate",
 "G2 comparison page reports Writesonic at 2,025 reviews and a 4.7/5 average rating, strong on SEO auditing and grammar-check dimensions.",
 "avg_rating|review_count","4.7|2025","https://g2.com/compare/copy-ai-vs-writesonic","2026-09-08"],
["cadetx_w002","Writesonic","eesel AI (industry roundup)","editorial_review","2026-06-10","eesel AI",
 "Roundup lists Writesonic among 8 platforms tested; entry pricing reaches $79/month for the Starter tier, among the highest of the four products studied.",
 "pricing_signal","starter_79_usd_month","https://www.eesel.ai/blog/ai-writing-tools-comparison","2026-09-08"],
["cadetx_w003","Writesonic","G2 (Jasper alternatives page)","aggregate_rating","2026 (live)","G2 aggregate",
 "G2 names Writesonic the top-ranked alternative to Jasper, with 2,092 total reviews and a 4.7/5 rating.",
 "avg_rating|review_count","4.7|2092","https://g2.com/products/jasper-ai/competitors/alternatives","2026-09-08"],
["cadetx_w004","Writesonic","Supademo (industry roundup)","editorial_review","2026-02-05","Supademo",
 "Roundup positions Writesonic as an all-in-one content-marketing platform (SEO AI features, chatbot capability), best suited to B2B go-to-market teams.",
 "editorial_positioning","best_for_b2b_gtm","https://supademo.com/blog/ai-copywriting-tools","2026-09-08"],

# ---------------- RYTR ----------------
["cadetx_r001","Rytr","G2 (AI Writer category page)","aggregate_rating","2026-06-28","G2 aggregate",
 "G2's AI Writer category page lists Rytr at 4.7/5 across 821 reviews.",
 "avg_rating|review_count","4.7|821","https://www.g2.com/products/ai-writer/reviews","2026-09-08"],
["cadetx_r002","Rytr","G2 (product reviews page)","individual_review","2026-07-14","Indresh Bahadur R.",
 "Reviewer describes Rytr as quick and convincing for completing writing tasks faster.",
 "review_rating","not stated (qualitative)","https://www.g2.com/products/rytr/reviews","2026-09-08"],
["cadetx_r003","Rytr","Contentellect (editorial review)","editorial_review","2026-05-18","Contentellect",
 "Vendor claims (per Rytr) of 8M+ users and 25M+ hours saved are reported alongside a 4.9/5 cross-platform rating claim; the independent reviewer scores Rytr only 3.5/5, citing limits beyond short-form writing.",
 "vendor_claim_vs_editorial_score","8M_users_claim | 3.5_editorial","https://www.contentellect.com/rytr-review/","2026-09-08"],
["cadetx_r004","Rytr","Writingful (editorial review)","aggregate_rating","undated","Writingful",
 "Reports G2 rating of 4.5/5 across 806 reviews and Capterra rating of 4.6/5 across only 18 reviews — both lower/smaller than figures reported elsewhere, showing snapshot variability.",
 "avg_rating|review_count","4.5|806","https://www.writingful.com/blog/rytr-review","2026-09-08"],
["cadetx_r005","Rytr","Retague (editorial review)","aggregate_rating","2026-04-09","Retague",
 "Reports Rytr at 4.7/5 on G2 with 800+ reviews; positions Rytr as the most aggressively priced mainstream AI writer at $9/month unlimited.",
 "avg_rating|pricing","4.7|9_usd_month_unlimited","https://retague.com/en/tool/rytr-ai-writing-review","2026-09-08"],
["cadetx_r006","Rytr","TopRatedAISoftware (editorial review)","aggregate_rating","2026-03-25","TopRatedAISoftware",
 "Reports G2 4.7/5 across ~800 reviews with 93.67% small-business reviewers, and Trustpilot 4.5/5 across 2,454 reviews.",
 "avg_rating|reviewer_segment","4.7|93.67pct_small_business","https://topratedaisoftware.com/article/rytr-review","2026-09-08"],
["cadetx_r007","Rytr","YourAISoft (investigative review)","editorial_review","2026-05-07","YourAISoft",
 "Investigative review flags that Rytr's Trustpilot score fell from a historic 4.9 to 4.5 across 2,455+ reviews after a platform review-quality penalty, and recommends cross-referencing G2 (4.7) as more reliable; also flags recurring complaints about no self-service account deletion.",
 "trustpilot_rating_change","4.9_to_4.5","https://youraisoft.com/rytr-review/","2026-09-08"],
["cadetx_r008","Rytr","G2 (head-to-head vs Semrush)","comparative_signal","2026 (live)","G2 aggregate",
 "G2 comparison shows Rytr scoring higher than Semrush on ease-of-use (9.5 vs 8.4) and content-creation tools (9.0 vs 8.3), but lower on SEO auditing (8.0) and competitor analysis.",
 "comparative_scores","ease_of_use_9.5|content_9.0|seo_8.0","https://www.g2.com/compare/rytr-vs-semrush","2026-09-08"],
]

header = ["signal_id","product","platform","source_type","date_observed","author_or_handle",
          "text_summary","metric_name","metric_value","url","access_date"]

with open("/home/claude/cadetx_project/data/raw/cadetx_task02_raw_all-products_2026-09-08.csv","w",newline="",encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(header)
    w.writerows(rows)

print(f"Wrote {len(rows)} rows.")
