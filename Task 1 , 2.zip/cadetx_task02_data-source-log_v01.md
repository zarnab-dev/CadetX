# CadetX Task 02 — Data Source Log & Collection Methodology

**Genre:** AI Writing Tools
**Products:** Jasper, Copy.ai, Writesonic, Rytr
**Collection date:** 2026-09-08
**Collector:** solo cadet, covering all four specialist roles

## Method

All data was collected via targeted web search and retrieval of live, public pages
during this session (no login, no paid API, no scraping of authenticated content).
Every row in `cadetx_task02_raw_all-products_2026-09-08.csv` traces to a real URL
that was actually opened/read this session. Text fields are paraphrased summaries,
not verbatim reproductions, in line with copyright limits — the source URL is the
place to read the original wording.

## Platforms actually used (and why)

CadetX's Data page names Twitter/X, Reddit, LinkedIn, YouTube and Product Hunt as
target platforms. In this environment:

- I have no authenticated API access to Twitter/X, Reddit, LinkedIn, or YouTube
  (no developer keys, no login), and general web search returned very little
  *individually attributable, metric-bearing* content for these four specific
  products on those platforms (mostly generic "how to use Product Hunt" advice
  articles, not actual per-product launch data).
- I will not fabricate realistic-looking tweets/Reddit threads with invented
  like/upvote counts to fill that gap — CadetX's own instructions explicitly
  prohibit fabricated social statistics.
- **Substitute real signal sources used instead:** G2, Capterra, Trustpilot,
  Gartner Peer Insights, and Chrome Web Store — these are public, consumer-
  generated review/discussion platforms with real usernames, dates, and
  (where shown) engagement counts (upvotes, comment counts). They are a
  legitimate, citable proxy for "consumer response / market sentiment," and
  several rows include genuine discussion-board threads (G2 Discussions) which
  behave like the intended social-post structure (thread starter, replies,
  upvotes).
- I also included **independent editorial roundups** (TechRadar, eesel AI,
  AIToolShop, AgenticCMO, Supademo, Contentellect, Writingful, Retague,
  TopRatedAISoftware, YourAISoft) because they aggregate and cross-check
  numbers across multiple platforms, which is itself a useful signal (e.g.
  flagging when a vendor's rating differs sharply across platforms).

## Known limitations (documented, not hidden)

1. **No raw individual post-level engagement data** (e.g. individual tweet
   like/retweet counts) was obtainable without API/login access. The dataset
   is therefore built primarily from **aggregate ratings + review counts**
   and a smaller number of **individually attributed reviews/discussion
   threads** where usernames, dates, and comment counts were genuinely shown.
2. **Numbers disagree across sources for the same product** (e.g. Copy.ai is
   reported as 182 reviews/4.7 on one G2 comparison page vs. "3,000+/4.8" by
   an aggregator, vs "25,014" on a category page; Rytr is reported as 806,
   818, 820, and 821 reviews at 4.5–4.7 depending on the page/date). This
   reflects real-world snapshot variability in review platforms (different
   pull dates, product vs. category rollups) rather than data entry error —
   it is itself a finding, flagged in each affected row.
3. **Product Hunt-specific launch data** (upvotes/comments at launch) was not
   found for these four established products via search — Product Hunt
   surfaced mostly as a generic discovery-platform topic, not product-specific
   launch metrics for Jasper/Copy.ai/Writesonic/Rytr. This is disclosed rather
   than backfilled with invented numbers.
4. **Sentiment is currently qualitative** (positive/negative/mixed tags per
   row) — a numeric sentiment score will be computed in Task 3/4 from the
   `text_summary` field using an NLP sentiment model, not fabricated here.

## Files produced

- `cadetx_task02_raw_all-products_2026-09-08.csv` — 29 real, cited signal rows
  across all 4 products (Jasper 9, Copy.ai 8, Writesonic 4, Rytr 8).
