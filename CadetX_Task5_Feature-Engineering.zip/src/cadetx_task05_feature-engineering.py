"""
CadetX Task 05 — Feature Engineering
Genre: AI Writing Tools | Products: Jasper, Copy.ai, Writesonic, Rytr

Input : data/cleaned/cadetx_task03_cleaned_all-products_v01.csv  (29 rows, Task 3)
Output: data/processed/cadetx_task05_signal-level-features_v01.csv   (29 rows)
        data/processed/cadetx_task05_product-level-features_v01.csv  (4 rows)

Design note (read before trusting any number downstream):
This dataset is 29 individually-sourced, real signals across 4 products, not a
bulk social-media pull. Feature engineering here therefore works at two grains:
  1. SIGNAL level (one row per collected signal, n=29) — used later for the
     supervised model in Task 6, because n=4 products is too small to train
     anything on directly.
  2. PRODUCT level (one row per product, n=4) — aggregates the signal-level
     features into per-product summary statistics. This is the grain the
     actual business question ("is this product launch-ready?") lives at,
     and feeds Task 7 (cross-product comparison) and Task 8 (unified
     framework) directly. It is NOT a modelling table on its own (n=4 is far
     too small for train/test ML) — it is a transparent aggregation.
No values are invented. Every feature is a deterministic function of columns
already present in the Task 3 cleaned dataset; parsing rules for messy raw
values (e.g. "3000+", "93.67pct_small_business") are documented inline.
"""

import re
import numpy as np
import pandas as pd

IN_PATH = "data/cleaned/cadetx_task03_cleaned_all-products_v01.csv"
OUT_SIGNAL = "data/processed/cadetx_task05_signal-level-features_v01.csv"
OUT_PRODUCT = "data/processed/cadetx_task05_product-level-features_v01.csv"

# ---------------------------------------------------------------------------
# Helpers — deterministic parsers for messy source-reported values
# ---------------------------------------------------------------------------

def parse_review_count(val):
    """Parse review_count_numeric / metric__review_count text into a float.
    '3000+' -> 3000.0 (documented as a floor, not an exact count).
    Anything else non-numeric -> NaN."""
    if pd.isna(val):
        return np.nan
    if isinstance(val, (int, float)):
        return float(val)
    s = str(val).strip()
    m = re.match(r"^(\d+(?:\.\d+)?)", s)
    return float(m.group(1)) if m else np.nan


def parse_price_usd_month(pricing_signal):
    """Extract a monthly USD price from strings like 'starter_79_usd_month'
    or '9_usd_month_unlimited'. Returns NaN if no such pattern exists."""
    if pd.isna(pricing_signal):
        return np.nan
    m = re.search(r"(\d+)_usd_month", str(pricing_signal))
    return float(m.group(1)) if m else np.nan


SENTIMENT_MAP = {
    "positive": 1.0,
    "mixed-positive": 0.5,
    "mixed": 0.0,
    "negative": -1.0,
}

# Simple, documented lexicon — small, transparent, offline (no external
# sentiment model). Used only as a *supplementary* text signal on top of the
# explicit source-reported sentiment tags, since most rows have no tag at all.
POS_WORDS = {
    "praises", "praise", "easy", "flexible", "flexibility", "best",
    "love", "consistency", "positioning", "top", "pick", "unlimited",
    "positive", "strong",
}
NEG_WORDS = {
    "concerns", "concern", "underwhelmed", "penalty", "negative",
    "flagged", "decline", "accuracy", "issue", "issues",
}


def lexicon_score(text):
    if pd.isna(text):
        return 0.0
    tokens = str(text).split()
    pos = sum(1 for t in tokens if t in POS_WORDS)
    neg = sum(1 for t in tokens if t in NEG_WORDS)
    total = pos + neg
    return 0.0 if total == 0 else (pos - neg) / total


REVIEW_PLATFORMS = {"G2", "G2 Discussions", "Capterra"}


def platform_bucket(platform):
    if platform in REVIEW_PLATFORMS or platform.startswith("G2") or platform == "Gartner Peer Insights":
        return "review_platform"
    if "investigative" in platform.lower():
        return "investigative_press"
    if "editorial" in platform.lower() or "roundup" in platform.lower() or "TechRadar" in platform:
        return "editorial"
    if "official" in platform.lower():
        return "vendor_owned"
    return "other"


# ---------------------------------------------------------------------------
# 1. Load
# ---------------------------------------------------------------------------

df = pd.read_csv(IN_PATH)
n_in = len(df)

# ---------------------------------------------------------------------------
# 2. SIGNAL-LEVEL feature engineering
# ---------------------------------------------------------------------------

feat = pd.DataFrame()
feat["signal_id"] = df["signal_id"]
feat["product"] = df["product"]
feat["platform"] = df["platform"]
feat["source_type"] = df["source_type"]

# --- Rating features -------------------------------------------------------
feat["rating"] = df["avg_rating_numeric"]
# rating_range (e.g. "4.0-5.0") -> midpoint, only used when avg_rating_numeric absent
def range_midpoint(s):
    if pd.isna(s):
        return np.nan
    m = re.match(r"(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)", str(s))
    return (float(m.group(1)) + float(m.group(2))) / 2 if m else np.nan

feat["rating"] = feat["rating"].fillna(df["metric__rating_range"].apply(range_midpoint))
feat["has_rating"] = feat["rating"].notna().astype(int)

# --- Volume features --------------------------------------------------------
rc = df["review_count_numeric"].apply(parse_review_count)
rc = rc.fillna(df["metric__category_review_count"])
feat["review_count"] = rc
feat["review_count_log1p"] = np.log1p(feat["review_count"])
feat["has_review_count"] = feat["review_count"].notna().astype(int)

# --- Engagement (discussion-thread) features --------------------------------
feat["upvotes"] = df["upvotes_numeric"].fillna(0)
feat["comments"] = df["comments_numeric"].fillna(0)
feat["engagement_total"] = feat["upvotes"] + feat["comments"]
feat["has_engagement"] = ((feat["upvotes"] > 0) | (feat["comments"] > 0)).astype(int)

# --- Sentiment features ------------------------------------------------------
tag_sentiment = df["metric__sentiment"].map(SENTIMENT_MAP)
verdict_sentiment = df["metric__editorial_verdict"].map(SENTIMENT_MAP)
compare_sentiment = df["metric__comparative_rating"].map(SENTIMENT_MAP)
feat["explicit_sentiment_score"] = tag_sentiment.combine_first(verdict_sentiment).combine_first(compare_sentiment)
feat["has_explicit_sentiment"] = feat["explicit_sentiment_score"].notna().astype(int)
feat["lexicon_sentiment_score"] = df["processed_text"].apply(lexicon_score)

# --- Momentum / editorial signal flags ---------------------------------------
feat["momentum_launch_announced"] = (df["metric__product_momentum_signal"] == "launch_announced").astype(int)
feat["editorial_top_pick"] = df["metric__editorial_rank"].fillna("").str.contains("top_pick").astype(int)
feat["editorial_best_for_flag"] = df["metric__editorial_positioning"].fillna("").str.contains("best_for").astype(int)
feat["cross_platform_gap_flag"] = (df["metric__cross_platform_rating_gap"] == "flagged").astype(int)
feat["trustpilot_decline_flag"] = df["metric__trustpilot_rating_change"].notna().astype(int)
feat["is_comparative_signal"] = (df["source_type"] == "comparative_signal").astype(int)
feat["is_discussion_thread"] = (df["source_type"] == "discussion_thread").astype(int)
feat["is_editorial_review"] = (df["source_type"] == "editorial_review").astype(int)

# --- Pricing -------------------------------------------------------------------
price_from_signal = df["metric__pricing_signal"].apply(parse_price_usd_month)
price_from_pricing = df["metric__pricing"].apply(parse_price_usd_month)
feat["price_usd_month"] = price_from_signal.combine_first(price_from_pricing)
feat["has_price_signal"] = feat["price_usd_month"].notna().astype(int)

# --- Platform context ------------------------------------------------------
feat["platform_bucket"] = df["platform"].apply(platform_bucket)

# --- Deterministic label for Task 6 (documented rule, no fabrication) -------
# favorable = 1 : clearly positive signal
# favorable = 0 : clearly negative / risk signal
# NaN         : genuinely ambiguous / no directional info -> excluded from modelling,
#               count and reason documented in Task 6 notes rather than silently dropped.
def label_row(row):
    neg_triggers = (
        row["explicit_sentiment_score"] == -1.0
        or row["cross_platform_gap_flag"] == 1
        or row["trustpilot_decline_flag"] == 1
    )
    pos_triggers = (
        row["momentum_launch_announced"] == 1
        or row["editorial_top_pick"] == 1
        or row["editorial_best_for_flag"] == 1
        or (pd.notna(row["rating"]) and row["rating"] >= 4.7 and not neg_triggers)
    )
    if neg_triggers:
        return 0
    if pos_triggers:
        return 1
    if row["explicit_sentiment_score"] == 0.5:  # mixed-positive, no negative trigger
        return 1
    if row["explicit_sentiment_score"] == 0.0:  # mixed / neutral comparative
        return np.nan
    if pd.notna(row["rating"]) and row["rating"] < 4.7:
        return 0
    return np.nan  # e.g. "not stated (qualitative)" reviews with no other signal

feat["favorable_signal_label"] = feat.apply(label_row, axis=1)

assert len(feat) == n_in, "Row count changed during feature engineering — investigate."
feat.to_csv(OUT_SIGNAL, index=False)

# ---------------------------------------------------------------------------
# 3. PRODUCT-LEVEL aggregation
# ---------------------------------------------------------------------------

agg = feat.groupby("product").agg(
    n_signals=("signal_id", "count"),
    n_platforms=("platform", "nunique"),
    n_source_types=("source_type", "nunique"),
    mean_rating=("rating", "mean"),
    max_review_count=("review_count", "max"),
    total_engagement=("engagement_total", "sum"),
    discussion_thread_count=("is_discussion_thread", "sum"),
    editorial_review_count=("is_editorial_review", "sum"),
    comparative_signal_count=("is_comparative_signal", "sum"),
    mean_explicit_sentiment=("explicit_sentiment_score", "mean"),
    mean_lexicon_sentiment=("lexicon_sentiment_score", "mean"),
    momentum_flag_count=("momentum_launch_announced", "sum"),
    editorial_top_pick_count=("editorial_top_pick", "sum"),
    cross_platform_gap_flag_count=("cross_platform_gap_flag", "sum"),
    trustpilot_decline_flag_count=("trustpilot_decline_flag", "sum"),
    min_price_usd_month=("price_usd_month", "min"),
    favorable_rate=("favorable_signal_label", "mean"),  # ignores NaN automatically
).reset_index()

# Derived, cross-feature ratios (documented: Feature -> Calculation -> Meaning)
agg["platform_diversity_ratio"] = agg["n_platforms"] / agg["n_signals"]
agg["source_type_diversity_ratio"] = agg["n_source_types"] / agg["n_signals"]
agg["engagement_per_signal"] = agg["total_engagement"] / agg["n_signals"]
agg["risk_flag_count"] = agg["cross_platform_gap_flag_count"] + agg["trustpilot_decline_flag_count"]
agg["review_volume_log1p"] = np.log1p(agg["max_review_count"])

agg.to_csv(OUT_PRODUCT, index=False)

print(f"Signal-level features: {feat.shape}")
print(f"Product-level features: {agg.shape}")
print(
    "\nLabel coverage (signal-level):",
    feat["favorable_signal_label"].notna().sum(), "/", len(feat),
    "rows labelled;",
    feat["favorable_signal_label"].isna().sum(), "excluded as ambiguous (documented, not guessed).",
)
