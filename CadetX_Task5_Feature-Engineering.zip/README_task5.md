# Task 5 — Feature Engineering (CadetX, AI Writing Tools genre)

## What's in this folder
```
data/cleaned/      Task 3 input (carried forward for traceability)
data/processed/    Task 5 outputs — the actual deliverable
  cadetx_task05_signal-level-features_v01.csv   (29 rows, feeds Task 6 model)
  cadetx_task05_product-level-features_v01.csv  (4 rows, feeds Task 7/8)
src/               cadetx_task05_feature-engineering.py — reproducible script
docs/              cadetx_task05_feature-dictionary_v01.md — Feature → Calculation → Meaning → Relevance for every column, plus the label rule and leakage check
```

## How to reproduce
```
python3 src/cadetx_task05_feature-engineering.py
```
Requires: pandas, numpy (both standard).

## One-line summary
19 of 29 real collected signals could be deterministically labelled favorable/
unfavorable from existing columns; the other 10 were left unlabelled rather
than guessed. Full reasoning in `docs/cadetx_task05_feature-dictionary_v01.md`.
