# CadetX Task 05 — Feature Engineering Dictionary

**Genre:** AI Writing Tools | **Products:** Jasper, Copy.ai, Writesonic, Rytr
**Input:** `data/cleaned/cadetx_task03_cleaned_all-products_v01.csv` (29 rows, Task 3)
**Output:**
- `data/processed/cadetx_task05_signal-level-features_v01.csv` (29 rows, 28 cols)
- `data/processed/cadetx_task05_product-level-features_v01.csv` (4 rows, 23 cols)
**Script:** `src/cadetx_task05_feature-engineering.py`

## Why two grains

The genre has 4 products but only 29 total collected signals (real, individually
sourced — see Task 2/3 notes). A modelling table with n=4 rows cannot support
train/test machine learning in any statistically meaningful way. So:

- **Signal-level table (n=29)** is the grain used for the actual predictive
  model in Task 6.
- **Product-level table (n=4)** is a transparent aggregation of the same
  features, used for cross-product comparison (Task 7) and the unified
  scoring framework (Task 8) — not for train/test ML.

No value in either table is invented. Every feature is a deterministic
function of a Task 3 column; parsing rules for messy source-reported values
(e.g. `"3000+"` → `3000.0`, `"starter_79_usd_month"` → `79.0`) are documented
in the script docstring and repeated below.

## Signal-level features

| Feature | Calculation | Meaning | Product-Launch relevance |
|---|---|---|---|
| `rating` | `avg_rating_numeric`, else midpoint of `rating_range` | Star rating on a 5-point scale | Baseline consumer-satisfaction signal |
| `has_rating` | 1 if `rating` present | Data-completeness flag | Distinguishes "no signal" from "bad signal" |
| `review_count` | `review_count_numeric` parsed (`"3000+"→3000`), else `category_review_count` | Volume of public reviews behind a rating | Market-traction signal — from EDA, more discriminating than rating |
| `review_count_log1p` | `log1p(review_count)` | Log-scaled volume | Avoids one large product (Writesonic/Copy.ai) dominating a linear model |
| `upvotes`, `comments` | `upvotes_numeric`/`comments_numeric`, NaN→0 | Discussion-thread engagement | Closest proxy in this dataset to "social engagement" |
| `engagement_total` | `upvotes + comments` | Combined thread engagement | Discussion velocity proxy |
| `has_engagement` | 1 if `engagement_total > 0` | Any thread activity at all | Sparse — most signals are ratings, not threads |
| `explicit_sentiment_score` | `metric__sentiment` / `metric__editorial_verdict` / `metric__comparative_rating` mapped `{positive:1, mixed-positive:0.5, mixed:0, negative:-1}` | Source-reported sentiment, numeric | Direct qualitative-to-quantitative sentiment signal |
| `has_explicit_sentiment` | 1 if a source actually tagged sentiment | Data-completeness flag | Most rows (aggregate ratings) carry none — flagged, not hidden |
| `lexicon_sentiment_score` | `(pos_words - neg_words) / (pos_words + neg_words)` over `processed_text`, small fixed lexicon | Supplementary text-derived sentiment | Fills gaps where no explicit tag exists; documented as a coarse proxy, not a trained sentiment model |
| `momentum_launch_announced` | 1 if `product_momentum_signal == "launch_announced"` | Explicit launch-momentum press signal | Direct product-launch relevance |
| `editorial_top_pick` | 1 if `editorial_rank` contains `"top_pick"` | Independent editorial endorsement | Strong positive signal, low volume |
| `editorial_best_for_flag` | 1 if `editorial_positioning` contains `"best_for"` | Positioning endorsement | Positive signal |
| `cross_platform_gap_flag` | 1 if `cross_platform_rating_gap == "flagged"` | Rating inconsistency across platforms flagged by a source | Reputation-risk signal |
| `trustpilot_decline_flag` | 1 if `trustpilot_rating_change` present | A platform rating dropped over time | Reputation-risk signal (drives Rytr's risk profile) |
| `is_comparative_signal`, `is_discussion_thread`, `is_editorial_review` | 1 if `source_type ==` that value | Source-type indicators | Feeds `source_type_diversity` at product level |
| `price_usd_month` | Regex-extracted `\d+_usd_month` from `metric__pricing_signal`/`metric__pricing` | Monthly USD price where a source stated one | Only 2/29 signals carry an explicit price — sparse, documented |
| `has_price_signal` | 1 if `price_usd_month` present | Data-completeness flag | — |
| `platform_bucket` | Rule-based bucket of `platform` into `review_platform` / `editorial` / `investigative_press` / `vendor_owned` / `other` | Where the signal came from | Feeds Fig 4 finding that platform mix is itself informative |
| `favorable_signal_label` | Deterministic rule (see below) | Binary target for Task 6 | See "Label rule" section |

## Label rule for `favorable_signal_label` (used only in Task 6)

This is a **rule-based label derived from existing columns**, not a fabricated
outcome variable. It is intentionally conservative: rows with no clear
directional signal are left `NaN` and excluded from modelling rather than
guessed.

- **→ 0 (unfavorable)** if any of: explicit sentiment is `negative`; a
  cross-platform rating gap was flagged; a Trustpilot rating decline was
  reported.
- **→ 1 (favorable)** if any of: `launch_announced` momentum; editorial
  `top_pick`; editorial `best_for` positioning; OR rating ≥ 4.7 with no
  negative trigger above; OR explicit sentiment is `mixed-positive` with no
  negative trigger.
- **→ NaN (excluded)** if sentiment is exactly `mixed`/neutral with no other
  signal, or the only information is a non-numeric qualitative review
  (`"not stated (qualitative)"`) with rating < 4.7 and no other flag.

Result: **19 of 29 signals labelled**, 10 excluded as genuinely ambiguous
(documented in the script's printed output, not silently dropped).

## Product-level features (aggregation of the above, n=4)

| Feature | Calculation | Meaning |
|---|---|---|
| `n_signals`, `n_platforms`, `n_source_types` | Counts per product | Breadth of available evidence |
| `mean_rating` | Mean of `rating` per product | Central rating tendency |
| `max_review_count` | Max `review_count` per product | Largest reported footprint (see Task 4 Fig 3 caveat on Copy.ai) |
| `review_volume_log1p` | `log1p(max_review_count)` | Log-scaled traction |
| `total_engagement`, `engagement_per_signal` | Sum / mean of `engagement_total` | Thread-engagement intensity |
| `discussion_thread_count`, `editorial_review_count`, `comparative_signal_count` | Sums of the signal-level flags | Composition of the evidence base |
| `mean_explicit_sentiment`, `mean_lexicon_sentiment` | Means of the two sentiment scores | Overall sentiment lean |
| `momentum_flag_count`, `editorial_top_pick_count` | Sums | Positive-signal counts |
| `cross_platform_gap_flag_count`, `trustpilot_decline_flag_count`, `risk_flag_count` | Sums / sum-of-sums | Reputation-risk counts |
| `min_price_usd_month` | Min of `price_usd_month` (NaN if never stated) | Cheapest explicitly-stated price point |
| `favorable_rate` | Mean of `favorable_signal_label` (NaN-aware) | Share of *labelled* signals that were favorable |
| `platform_diversity_ratio`, `source_type_diversity_ratio` | `n_platforms / n_signals`, `n_source_types / n_signals` | Evidence-base breadth relative to volume |

## Leakage check

`favorable_signal_label` is derived partly from `rating` and sentiment tags.
Task 6 explicitly excludes `rating`, `explicit_sentiment_score`, and the
sentiment/verdict-derived label-trigger columns from the **feature set** used
to *predict* the label — otherwise the model would trivially reconstruct its
own labelling rule. See Task 6 documentation for the exact feature list used.

## Known limitations carried forward

- n=29 signal-level rows, n=4 products — both are small; every downstream
  statistic should be read as directional, not statistically robust (same
  caveat as Task 4).
- The lexicon sentiment score uses a ~20-word hand-built list, not a trained
  sentiment classifier — it is a coarse supplementary signal, disclosed as
  such, not a substitute for real NLP sentiment scoring on a larger corpus.
- `price_usd_month` is populated for only 2 of 29 signals; treated as
  informative-when-present, not filled in or guessed elsewhere.
