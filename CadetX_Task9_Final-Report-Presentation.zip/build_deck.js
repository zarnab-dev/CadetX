const pptxgen = require("pptxgenjs");

// ---- Palette: "Midnight Executive" (navy / ice blue), tier colors reused from charts ----
const NAVY = "1E2761";
const ICE = "CADCFC";
const WHITE = "FFFFFF";
const SLATE = "444444";
const GREEN = "2C5F2D";
const AMBER = "E8A33D";
const RED = "B03A2E";
const LIGHTBG = "F7F8FC";

const A = "report_assets";

function newSlide(pres, bg = WHITE) {
  const s = pres.addSlide();
  s.background = { color: bg };
  return s;
}

function title(slide, text, opts = {}) {
  slide.addText(text, {
    x: 0.6, y: 0.4, w: 12.1, h: 0.9,
    fontFace: "Cambria", fontSize: opts.size || 32, bold: true,
    color: opts.color || NAVY, isTextBox: true,
  });
}

function kicker(slide, text, color = AMBER) {
  slide.addText(text.toUpperCase(), {
    x: 0.6, y: 0.15, w: 8, h: 0.3,
    fontFace: "Calibri", fontSize: 12, bold: true, charSpacing: 2,
    color, isTextBox: true,
  });
}

function footer(slide, n) {
  slide.addText(`CadetX — AI Writing Tools · ${n}`, {
    x: 0.6, y: 7.15, w: 6, h: 0.3, fontFace: "Calibri", fontSize: 9,
    color: "999999", isTextBox: true,
  });
}

async function build() {
  const pres = new pptxgen();
  pres.layout = "LAYOUT_WIDE"; // 13.3 x 7.5

  // ============================================================ Slide 1 — Title
  let s = newSlide(pres, NAVY);
  s.addText("CadetX", {
    x: 0.8, y: 0.6, w: 4, h: 0.5, fontFace: "Calibri", fontSize: 16, bold: true,
    color: ICE, charSpacing: 3, isTextBox: true,
  });
  s.addText("Product Launch Analytics", {
    x: 0.8, y: 2.5, w: 11.5, h: 1.6, fontFace: "Cambria", fontSize: 48, bold: true,
    color: WHITE, isTextBox: true,
  });
  s.addText("AI Writing Tools genre — Jasper · Copy.ai · Writesonic · Rytr", {
    x: 0.8, y: 4.05, w: 11.5, h: 0.6, fontFace: "Calibri", fontSize: 20,
    color: ICE, isTextBox: true,
  });
  s.addText("Solo submission covering all four specialist roles · Final report & presentation (Task 9)", {
    x: 0.8, y: 6.6, w: 11.5, h: 0.4, fontFace: "Calibri", fontSize: 12,
    color: "8FA0D8", isTextBox: true,
  });

  // ============================================================ Slide 2 — The problem
  s = newSlide(pres);
  kicker(s, "The Product Launch Problem");
  title(s, "How launch-ready does a product look,\nbased on what the market is already saying?");
  s.addShape(pres.ShapeType.roundRect, { x: 0.6, y: 2.6, w: 11.9, h: 2.0, fill: { color: LIGHTBG }, line: { color: LIGHTBG }, rectRadius: 0.08 });
  s.addText([
    { text: "Given public social and market signals about a product, ", options: {} },
    { text: "which signals generalize across a genre and which are product-specific?", options: { bold: true, color: NAVY } },
  ], { x: 1.0, y: 2.85, w: 11.1, h: 1.5, fontFace: "Calibri", fontSize: 18, color: SLATE, isTextBox: true, valign: "top" });
  s.addText("Four products chosen to stress-test that question: they differ in price ($9\u2013$69+/mo), positioning, and review-platform profile.", {
    x: 1.0, y: 5.0, w: 11.1, h: 0.6, fontFace: "Calibri", fontSize: 13, italic: true, color: "666666", isTextBox: true,
  });
  footer(s, "Problem");

  // ============================================================ Slide 3 — Data & Methodology
  s = newSlide(pres);
  kicker(s, "Data");
  title(s, "29 real, traceable signals — no fabricated data");
  const dataCols = [
    ["29", "Individually-sourced signals collected across 4 products"],
    ["7", "Real platforms: G2, G2 Discussions, Capterra, Gartner Peer Insights, Trustpilot, editorial press, official channels"],
    ["0", "Fabricated rows. Twitter/X, Reddit, LinkedIn, YouTube had no accessible API — disclosed as a gap, not filled with invented numbers"],
  ];
  dataCols.forEach((d, i) => {
    const x = 0.6 + i * 4.13;
    s.addShape(pres.ShapeType.roundRect, { x, y: 2.4, w: 3.9, h: 3.4, fill: { color: LIGHTBG }, line: { color: LIGHTBG }, rectRadius: 0.08 });
    s.addText(d[0], { x, y: 2.65, w: 3.9, h: 1.1, align: "center", fontFace: "Cambria", fontSize: 54, bold: true, color: NAVY, isTextBox: true });
    s.addText(d[1], { x: x + 0.25, y: 3.75, w: 3.4, h: 1.8, align: "center", fontFace: "Calibri", fontSize: 13, color: SLATE, isTextBox: true });
  });
  footer(s, "Data & Methodology");

  // ============================================================ Slide 4 — EDA: rating & volume
  s = newSlide(pres);
  kicker(s, "Exploratory Data Analysis");
  title(s, "Rating barely differentiates this genre. Volume does.");
  s.addImage({ path: `${A}/cadetx_task04_fig02_avg-rating-by-product.png`, x: 0.6, y: 2.3, w: 6.0, h: 3.5 });
  s.addImage({ path: `${A}/cadetx_task04_fig03_review-volume-by-product.png`, x: 6.9, y: 2.3, w: 6.0, h: 3.5 });
  s.addText("All 4 products sit in a narrow 4.6\u20134.8 star band — but review volume spans orders of magnitude, log-scaled here.", {
    x: 0.6, y: 5.95, w: 12.1, h: 0.5, fontFace: "Calibri", fontSize: 13, italic: true, color: "666666", isTextBox: true,
  });
  footer(s, "EDA");

  // ============================================================ Slide 5 — Platform mix
  s = newSlide(pres);
  kicker(s, "Exploratory Data Analysis");
  title(s, "Where the genre actually talks: B2B review platforms, not social");
  s.addImage({ path: `${A}/cadetx_task04_fig04_platform-mix-by-product.png`, x: 2.4, y: 2.2, w: 8.5, h: 4.6 });
  footer(s, "EDA — Platform Mix");

  // ============================================================ Slide 6 — Feature Engineering
  s = newSlide(pres);
  kicker(s, "Feature Engineering");
  title(s, "From 29 raw signals to a modelling-ready feature set");
  const feats = [
    ["Signal-level table", "29 rows × 28 features — rating, sentiment, momentum, risk flags, engineered per-row"],
    ["Product-level table", "4 rows × 23 features — aggregated for comparison & the readiness framework"],
    ["Documented label rule", "19 of 29 signals labelled favorable/unfavorable; 10 left unlabelled as genuinely ambiguous — not guessed"],
  ];
  feats.forEach((f, i) => {
    const y = 2.35 + i * 1.35;
    s.addShape(pres.ShapeType.roundRect, { x: 0.6, y, w: 0.55, h: 0.55, fill: { color: NAVY }, line: { color: NAVY }, rectRadius: 0.5 });
    s.addText(String(i + 1), { x: 0.6, y, w: 0.55, h: 0.55, align: "center", valign: "middle", fontFace: "Calibri", fontSize: 20, bold: true, color: WHITE, isTextBox: true });
    s.addText(f[0], { x: 1.4, y: y - 0.05, w: 5.0, h: 0.4, fontFace: "Calibri", fontSize: 16, bold: true, color: NAVY, isTextBox: true });
    s.addText(f[1], { x: 1.4, y: y + 0.35, w: 10.8, h: 0.7, fontFace: "Calibri", fontSize: 13, color: SLATE, isTextBox: true });
  });
  footer(s, "Feature Engineering");

  // ============================================================ Slide 7 — Prediction Model
  s = newSlide(pres);
  kicker(s, "Prediction Model");
  title(s, "The honest result: accuracy looks fine. AUC does not.");
  s.addImage({ path: `${A}/cadetx_task09_fig_model-metrics.png`, x: 0.6, y: 2.2, w: 7.0, h: 4.4 });
  s.addShape(pres.ShapeType.roundRect, { x: 7.9, y: 2.2, w: 4.8, h: 4.4, fill: { color: LIGHTBG }, line: { color: LIGHTBG }, rectRadius: 0.08 });
  s.addText([
    { text: "ROC-AUC of 0.19\u20130.26 ", options: { bold: true, color: RED } },
    { text: "is below the 0.5 random-guessing line.\n\n", options: {} },
    { text: "Why: the label is imbalanced (14 favorable / 5 unfavorable) — both models mostly predict \u201cfavorable\u201d for everything, which flatters accuracy while ranking poorly.\n\n", options: {} },
    { text: "Reported as the headline modelling finding, not hidden behind the nicer accuracy number.", options: { italic: true } },
  ], { x: 8.15, y: 2.45, w: 4.3, h: 3.9, fontFace: "Calibri", fontSize: 13, color: SLATE, isTextBox: true, valign: "top" });
  footer(s, "Prediction Model");

  // ============================================================ Slide 8 — Cross-product comparison
  s = newSlide(pres);
  kicker(s, "Cross-Product Comparison");
  title(s, "Rating is universal. Sentiment, risk & engagement are not.");
  s.addImage({ path: `${A}/cadetx_task07_fig02_feature-radar-normalized.png`, x: 1.4, y: 2.2, w: 10.5, h: 4.6 });
  footer(s, "Cross-Product Comparison");

  // ============================================================ Slide 9 — Readiness vs Risk
  s = newSlide(pres);
  kicker(s, "Cross-Product Comparison");
  title(s, "Readiness vs. risk, by product");
  s.addImage({ path: `${A}/cadetx_task07_fig01_readiness-vs-risk.png`, x: 2.6, y: 2.1, w: 8.1, h: 5.0 });
  footer(s, "Readiness vs Risk");

  // ============================================================ Slide 10 — LRI Framework
  s = newSlide(pres);
  kicker(s, "Launch Success Framework");
  title(s, "The Launch Readiness Index (LRI)");
  const rows = [
    [{ text: "Component", options: { bold: true, color: WHITE, fill: NAVY } }, { text: "Weight", options: { bold: true, color: WHITE, fill: NAVY } }, { text: "Anchor", options: { bold: true, color: WHITE, fill: NAVY } }],
    ["Rating", "0.10", "Fixed 1\u20135 star scale"],
    ["Review volume", "0.20", "Fixed ceiling log1p(5000)"],
    ["Sentiment", "0.20", "Fixed [\u22121,+1] rescaled"],
    ["Editorial endorsement", "0.15", "Fixed ceiling 1.5"],
    ["Engagement presence", "0.10", "Fixed ceiling 2.0/signal"],
    ["Model readiness", "0.25", "Already [0,1] probability"],
    ["Risk penalty", "\u22120.20", "Fixed ceiling 3 flags"],
  ];
  s.addTable(rows, {
    x: 0.6, y: 2.25, w: 7.3, colW: [3.2, 1.3, 2.8], fontSize: 12, fontFace: "Calibri",
    color: SLATE, border: { type: "solid", color: "DDDDDD", pt: 0.5 }, autoPage: false,
  });
  s.addShape(pres.ShapeType.roundRect, { x: 8.2, y: 2.25, w: 4.5, h: 4.6, fill: { color: LIGHTBG }, line: { color: LIGHTBG }, rectRadius: 0.08 });
  s.addText("Fixed anchors, not within-sample min-max", { x: 8.45, y: 2.5, w: 4.0, h: 0.5, fontFace: "Calibri", fontSize: 14, bold: true, color: NAVY, isTextBox: true });
  s.addText("Min-max across only 4 products would force one to 0 and one to 1 on every feature \u2014 and would break the moment a 5th product needed scoring. Fixed anchors keep the score meaningful for future launches.", {
    x: 8.45, y: 3.05, w: 4.0, h: 1.9, fontFace: "Calibri", fontSize: 12, color: SLATE, isTextBox: true,
  });
  s.addText("Tiers: \u2265 0.70 Launch-Ready  ·  0.50\u20130.70 Monitoring  ·  < 0.50 Needs Remediation", {
    x: 8.45, y: 5.1, w: 4.0, h: 1.4, fontFace: "Calibri", fontSize: 12, italic: true, color: "666666", isTextBox: true,
  });
  footer(s, "Launch Success Framework");

  // ============================================================ Slide 11 — LRI results
  s = newSlide(pres);
  kicker(s, "Launch Success Framework");
  title(s, "Results: Launch Readiness Index by product");
  s.addImage({ path: `${A}/cadetx_task09_fig_lri-scores.png`, x: 1.6, y: 2.1, w: 10.0, h: 4.8 });
  footer(s, "LRI Results");

  // ============================================================ Slide 12 — Recommendations
  s = newSlide(pres);
  kicker(s, "Business Recommendations");
  title(s, "What the evidence supports doing next");
  const recs = [
    "Weight review-platform volume & engagement above star rating \u2014 rating won't differentiate products in this genre.",
    "Treat reputation-risk flags as a hard penalty \u2014 both flagged products (Copy.ai, Rytr) scored meaningfully lower.",
    "Prioritize collecting engagement data \u2014 it exists for only 1 of 4 products today, and was one of the strongest signals where present.",
    "Distinguish editorial endorsement from investigative press scrutiny when tracking \u201cinfluencer impact.\u201d",
    "Fix the model's data-volume gap (AUC < 0.5) before trusting it at higher stakes \u2014 more data, not more model complexity.",
  ];
  recs.forEach((r, i) => {
    const y = 2.25 + i * 0.92;
    s.addShape(pres.ShapeType.ellipse, { x: 0.6, y: y + 0.02, w: 0.32, h: 0.32, fill: { color: AMBER }, line: { color: AMBER } });
    s.addText(String(i + 1), { x: 0.6, y: y + 0.02, w: 0.32, h: 0.32, align: "center", valign: "middle", fontFace: "Calibri", fontSize: 13, bold: true, color: WHITE, isTextBox: true });
    s.addText(r, { x: 1.15, y, w: 11.5, h: 0.85, fontFace: "Calibri", fontSize: 14, color: SLATE, isTextBox: true, valign: "top" });
  });
  footer(s, "Recommendations");

  // ============================================================ Slide 13 — Limitations
  s = newSlide(pres);
  kicker(s, "Limitations & Future Work");
  title(s, "What would need to improve before this scales");
  const lims = [
    ["Sample size", "29 signals, 4 products, 19 labelled rows \u2014 read every statistic as directional"],
    ["Model discriminative power", "AUC below 0.5, yet weighted highest (0.25) in the LRI \u2014 a disclosed tension"],
    ["Platform coverage", "No Twitter/X, Reddit, LinkedIn, or YouTube API access in this environment"],
    ["Engagement coverage", "Captured for only 1 of 4 products \u2014 an availability gap, not a real-world null result"],
  ];
  lims.forEach((l, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = 0.6 + col * 6.2, y = 2.3 + row * 2.3;
    s.addShape(pres.ShapeType.roundRect, { x, y, w: 5.9, h: 2.0, fill: { color: LIGHTBG }, line: { color: LIGHTBG }, rectRadius: 0.08 });
    s.addText(l[0], { x: x + 0.3, y: y + 0.2, w: 5.3, h: 0.5, fontFace: "Calibri", fontSize: 15, bold: true, color: NAVY, isTextBox: true });
    s.addText(l[1], { x: x + 0.3, y: y + 0.7, w: 5.3, h: 1.15, fontFace: "Calibri", fontSize: 12.5, color: SLATE, isTextBox: true });
  });
  footer(s, "Limitations");

  // ============================================================ Slide 14 — Conclusion
  s = newSlide(pres, NAVY);
  s.addText("A complete, traceable pipeline \u2014\nreported honestly at every stage", {
    x: 0.8, y: 2.2, w: 11.7, h: 1.8, fontFace: "Cambria", fontSize: 34, bold: true, color: WHITE, isTextBox: true,
  });
  s.addText("From real, individually-sourced signals to a transparent, genre-generalizable Launch Readiness Index \u2014 including reporting a model result that looked worse under a stricter metric, because that's what the evidence showed.", {
    x: 0.8, y: 4.1, w: 10.5, h: 1.3, fontFace: "Calibri", fontSize: 16, color: ICE, isTextBox: true,
  });
  s.addText("Thank you", { x: 0.8, y: 6.3, w: 6, h: 0.6, fontFace: "Calibri", fontSize: 16, bold: true, color: AMBER, isTextBox: true });

  await pres.writeFile({ fileName: "cadetx_task09_final-presentation_v01.pptx" });
  console.log("Deck written.");
}

build();
