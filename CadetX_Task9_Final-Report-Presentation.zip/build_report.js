const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, ImageRun, AlignmentType, BorderStyle, PageBreak,
} = require("docx");

const A = "report_assets";

function h1(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_1, spacing: { before: 300, after: 150 } });
}
function h2(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_2, spacing: { before: 200, after: 100 } });
}
function p(text, opts = {}) {
  return new Paragraph({ children: [new TextRun({ text, ...opts })], spacing: { after: 120 } });
}
function bullet(text, opts = {}) {
  return new Paragraph({ children: [new TextRun({ text, ...opts })], bullet: { level: 0 }, spacing: { after: 60 } });
}
function bold(text) { return new TextRun({ text, bold: true }); }

function img(path, widthIn, heightIn, caption) {
  const data = fs.readFileSync(path);
  const children = [
    new Paragraph({
      children: [new ImageRun({ data, transformation: { width: widthIn * 96, height: heightIn * 96 }, type: "png" })],
      alignment: AlignmentType.CENTER,
      spacing: { before: 150, after: 60 },
    }),
  ];
  if (caption) {
    children.push(new Paragraph({
      children: [new TextRun({ text: caption, italics: true, size: 18, color: "555555" })],
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
    }));
  }
  return children;
}

function cell(text, opts = {}) {
  return new TableCell({
    width: { size: opts.width || 2000, type: WidthType.DXA },
    shading: opts.header ? { fill: "1E2761", type: ShadingType.CLEAR } : undefined,
    children: [new Paragraph({
      children: [new TextRun({ text, bold: !!opts.header, color: opts.header ? "FFFFFF" : "000000", size: opts.size || 20 })],
    })],
  });
}

function table(headers, rows, widths) {
  const headerRow = new TableRow({ children: headers.map((h, i) => cell(h, { header: true, width: widths[i] })) });
  const bodyRows = rows.map(r => new TableRow({ children: r.map((c, i) => cell(String(c), { width: widths[i] })) }));
  return new Table({
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    columnWidths: widths,
    rows: [headerRow, ...bodyRows],
  });
}

const sections = [];

// ---------------------------------------------------------------------
// Title page
// ---------------------------------------------------------------------
sections.push(
  new Paragraph({ text: "CadetX — Product Launch Analytics Project", heading: HeadingLevel.TITLE, spacing: { after: 100 } }),
  new Paragraph({ text: "Final Report: AI Writing Tools Genre", heading: HeadingLevel.HEADING_2, spacing: { after: 300 } }),
  p("Genre: AI Writing Tools", { bold: true }),
  p("Products analyzed: Jasper, Copy.ai, Writesonic, Rytr", { bold: true }),
  p("Submission mode: Solo — all four specialist roles covered by one analyst", { bold: true }),
  p("Tasks covered: 01–10, CadetX Product Launch Analytics program"),
  new Paragraph({ children: [new PageBreak()] }),
);

// ---------------------------------------------------------------------
// 1. Executive Summary
// ---------------------------------------------------------------------
sections.push(h1("1. Executive Summary"));
sections.push(p(
  "This project builds and tests a launch-readiness analytics pipeline for the AI Writing " +
  "Tools genre, using four established products — Jasper, Copy.ai, Writesonic, and Rytr — as " +
  "a proof of concept for a framework intended to generalize to future launches in the genre."
));
sections.push(p(
  "29 real, individually-sourced signals were collected from public review platforms (G2, " +
  "Capterra, Trustpilot, Gartner Peer Insights) and independent editorial coverage — not " +
  "fabricated social-media data, since authenticated Twitter/X, Reddit, LinkedIn, and YouTube " +
  "access was not available in this environment (Task 2). Every subsequent task builds " +
  "traceably on this real dataset."
));
sections.push(p("Key results, stated plainly:"));
sections.push(bullet("Star rating is a near-universal but weak differentiator in this genre — all four products sit in a narrow 4.6–4.8 band."));
sections.push(bullet("Reputation-risk flags (a cross-platform rating gap for Copy.ai; a Trustpilot rating decline for Rytr) and discussion-engagement presence are the strongest differentiators found."));
sections.push(bullet("A supervised model (Logistic Regression / Random Forest) was trained to classify signals as favorable/unfavorable; it achieved reasonable accuracy (0.68–0.74) but a ROC-AUC below 0.5 — meaning it does not yet discriminate better than chance. This is reported as a primary, honest finding, not hidden behind the better-looking accuracy number."));
sections.push(bullet("A Launch Readiness Index (LRI) — a transparent, fixed-anchor composite score — ranks the four products: Jasper (0.740, Launch-Ready), Writesonic (0.702, Launch-Ready), Copy.ai (0.556, Launch with Monitoring), Rytr (0.489, Needs Remediation)."));
sections.push(p(
  "The project is delivered with full traceability: every number in this report can be traced " +
  "back to a real, cited URL via the Task 2 data-source log, through the cleaning, feature-" +
  "engineering, and modelling pipeline documented in Tasks 3–8."
));

// ---------------------------------------------------------------------
// 2. Problem Statement
// ---------------------------------------------------------------------
sections.push(h1("2. Product Launch Problem Statement"));
sections.push(p(
  "Given public social and market signals about a product, how launch-ready or launch-" +
  "successful does it appear to be — and which signals generalize across products in a genre " +
  "versus which are product-specific? This project answers that question for the AI Writing " +
  "Tools genre using four products chosen specifically to stress-test it: they differ in price " +
  "tier ($9–69+/mo), positioning (enterprise brand voice vs. budget short-form), and review-" +
  "platform profile, so a genuinely generalizable framework should hold up across that spread."
));

// ---------------------------------------------------------------------
// 3. Objectives
// ---------------------------------------------------------------------
sections.push(h1("3. Objectives"));
sections.push(bullet("Collect real, traceable social/market signal data for four products in one genre (Task 2)."));
sections.push(bullet("Clean and normalize that data into a reproducible pipeline (Task 3)."));
sections.push(bullet("Surface early product-launch-relevant patterns via EDA (Task 4)."));
sections.push(bullet("Engineer features that connect raw signals to launch-relevant constructs (Task 5)."));
sections.push(bullet("Train and honestly evaluate a predictive model of signal favorability (Task 6)."));
sections.push(bullet("Compare all four products to find universal vs. product-specific predictors (Task 7)."));
sections.push(bullet("Merge the above into one transparent, reusable Launch Readiness Index (Task 8)."));
sections.push(bullet("Consolidate everything into this report + a slide deck (Task 9), then close with a final audit and reflection (Task 10)."));

// ---------------------------------------------------------------------
// 4. Product/Genre Selection
// ---------------------------------------------------------------------
sections.push(h1("4. Product & Genre Selection"));
sections.push(p("Genre: AI Writing Tools.", { bold: true }));
sections.push(table(
  ["Product", "Positioning", "Selection rationale"],
  [
    ["Jasper", "Enterprise/marketing brand-voice, $59-69+/seat/mo", "Largest, most established player; richest G2 review base (1,269 reviews)"],
    ["Copy.ai", "Short-form copy + GTM workflow automation", "Jasper's closest premium competitor; frequently directly compared to Jasper"],
    ["Writesonic", "SEO long-form + all-in-one content suite", "G2's top-ranked Jasper alternative; largest review volume of the four (2,025-2,092)"],
    ["Rytr", "Budget short-form writer, $9/mo unlimited", "Clear price outlier; only product with a documented Trustpilot rating controversy"],
  ],
  [1700, 3400, 4160],
));
sections.push(p(""));
sections.push(p(
  "All four products' engagement concentrates on B2B review platforms (G2, Capterra, " +
  "Trustpilot, Gartner) rather than Twitter/X, Reddit, or LinkedIn specifically — itself a " +
  "genre-level finding carried through the whole project, not an assumption made at the start."
));

// ---------------------------------------------------------------------
// 5. Data Sources & Collection Methodology
// ---------------------------------------------------------------------
sections.push(h1("5. Data Sources & Collection Methodology"));
sections.push(p(
  "All data traces to real, public URLs opened during collection: G2, G2 Discussions, " +
  "Capterra, Gartner Peer Insights, and independent editorial/press coverage (TechRadar, " +
  "eesel AI, AIToolShop, AgenticCMO, Supademo, Contentellect, Writingful, Retague, " +
  "TopRatedAISoftware, YourAISoft). Text fields are paraphrased summaries, not verbatim " +
  "reproductions of source text."
));
sections.push(p("Final dataset: 29 signals across 4 products (Jasper 9, Copy.ai 8, Rytr 8, Writesonic 4)."));

// ---------------------------------------------------------------------
// 6. Data Limitations
// ---------------------------------------------------------------------
sections.push(h1("6. Data Limitations"));
sections.push(bullet("No authenticated API/login access to Twitter/X, Reddit, LinkedIn, or YouTube — no individually-attributable post-level engagement data from those platforms exists in this dataset. No data was fabricated to fill this gap."));
sections.push(bullet("Numbers disagree across sources for the same product (e.g. Copy.ai reported as 182, 3,000+, and 25,014 reviews depending on page scope) — a real snapshot-variability finding, flagged per-row rather than silently resolved."));
sections.push(bullet("No Product Hunt launch-day metrics were discoverable for these four mature, already-launched products."));
sections.push(bullet("Sample size is small throughout (29 signals, 4 products) — every statistic in this report should be read as directional, not statistically robust."));

// ---------------------------------------------------------------------
// 7. Data Cleaning & NLP Text Processing
// ---------------------------------------------------------------------
sections.push(h1("7. Data Cleaning & NLP Text Processing"));
sections.push(p("Task 3 applied a reproducible cleaning pipeline to the 29 raw signals:"));
sections.push(bullet("De-duplication on (url, text_summary) — no duplicates found."));
sections.push(bullet("Timestamp normalization — genuinely undated rows (e.g. \"undated\", \"2026 (live)\") were left null rather than guessed."));
sections.push(bullet("Compound metric fields (e.g. \"avg_rating|review_count\") parsed into 21 individual numeric/text metric columns."));
sections.push(bullet("Text normalization on text_summary → processed_text: lowercased, URLs/hashtags/punctuation stripped, tokenized, stopwords removed, lightly stemmed (custom suffix stripper, documented as not a full Porter stemmer)."));
sections.push(bullet("Engagement fields (upvotes, comments) converted to numeric."));
sections.push(p("Result: a 29-row, 38-column cleaned dataset feeding all downstream tasks."));

// ---------------------------------------------------------------------
// 8. Exploratory Data Analysis
// ---------------------------------------------------------------------
sections.push(h1("8. Exploratory Data Analysis"));
sections.push(p(
  "Task 4's EDA (built on the 29-signal cleaned dataset) surfaced the genre's first directional " +
  "patterns:"
));
sections.push(...img(`${A}/cadetx_task04_fig02_avg-rating-by-product.png`, 5.5, 3.2,
  "Fig. 2 — Mean public review rating by product. All four sit in a narrow 4.5-4.9 band."));
sections.push(...img(`${A}/cadetx_task04_fig03_review-volume-by-product.png`, 5.5, 3.2,
  "Fig. 3 — Reported review volume by product (log scale). Far more discriminating than rating."));
sections.push(...img(`${A}/cadetx_task04_fig04_platform-mix-by-product.png`, 5.5, 3.2,
  "Fig. 4 — Where each product's signals came from. Rytr's mix is dominated by independent editorial/press coverage, driven by its Trustpilot story."));
sections.push(p("Cross-cutting EDA insight: rating compresses across the genre while volume and press-attention spread out — so a launch framework should weight volume, engagement, and press attention more heavily than star rating (directly informing the Task 8 weighting)."));

// ---------------------------------------------------------------------
// 9. Feature Engineering
// ---------------------------------------------------------------------
sections.push(h1("9. Feature Engineering"));
sections.push(p(
  "Task 5 engineered features at two grains from the cleaned data: a 29-row signal-level table " +
  "(feeding the Task 6 model) and a 4-row product-level table (feeding Tasks 7-8). No values " +
  "were invented — every feature is a deterministic function of a Task 3 column."
));
sections.push(table(
  ["Feature", "Calculation", "Product-launch relevance"],
  [
    ["review_count_log1p", "log1p(review_count)", "Market-traction signal; more discriminating than rating"],
    ["explicit_sentiment_score", "Sentiment/verdict tags mapped to {-1, 0, 0.5, 1}", "Direct qualitative-to-quantitative sentiment"],
    ["lexicon_sentiment_score", "(pos-neg words)/(pos+neg words) over processed_text", "Supplementary text-derived sentiment, coarse but disclosed as such"],
    ["momentum_launch_announced", "1 if momentum signal == launch_announced", "Direct launch-momentum signal"],
    ["cross_platform_gap_flag / trustpilot_decline_flag", "1 if source flagged a rating inconsistency/decline", "Reputation-risk signal"],
    ["favorable_signal_label", "Rule-based mapping of rating/sentiment/momentum/risk", "Task 6 modelling target (19/29 rows labelled; 10 excluded as ambiguous)"],
  ],
  [2500, 3260, 3500],
));

// ---------------------------------------------------------------------
// 10. Predictive Modelling & Model Evaluation
// ---------------------------------------------------------------------
sections.push(h1("10. Predictive Modelling & Model Evaluation"));
sections.push(p(
  "\"Success\" was operationalised at the signal level (favorable_signal_label, a documented " +
  "rule) since no genre-standard launch-success outcome exists in this dataset. With only 19 " +
  "labelled rows, Leave-One-Out Cross-Validation (LOOCV) was used instead of a train/test split " +
  "— the standard, honest choice at this sample size."
));
sections.push(...img(`${A}/cadetx_task09_fig_model-metrics.png`, 5.5, 3.3,
  "Fig. 5 — LOOCV metrics for both models. Accuracy/F1 look reasonable; ROC-AUC does not."));
sections.push(p(
  "Both models — Logistic Regression and Random Forest — achieved accuracy of 0.68-0.74 and F1 " +
  "of 0.81-0.85, but ROC-AUC of only 0.19-0.26 (below the 0.5 random-guessing baseline). This is " +
  "explained, not hidden: the label is imbalanced (14 favorable / 5 unfavorable), so a model " +
  "that predicts \"favorable\" for nearly everything scores well on accuracy while ranking " +
  "poorly. The honest conclusion: neither model currently has genuine discriminative power for " +
  "this target at this sample size.", {}
));

// ---------------------------------------------------------------------
// 11. Key Predictors
// ---------------------------------------------------------------------
sections.push(h1("11. Key Predictors"));
sections.push(p("From Task 6 feature importance (Random Forest / Logistic Regression):"));
sections.push(bullet("Strongest: lexicon_sentiment_score (text-derived sentiment) — though built on a small hand-made lexicon, disclosed as a limitation, not a strength."));
sections.push(bullet("Moderate: review_count_log1p, has_rating."));
sections.push(bullet("Near-zero: engagement_total, is_discussion_thread, has_engagement — because engagement data exists for only 1 of 4 products (Jasper), so the model correctly treats it as ungeneralizable given current data, not as \"unimportant in reality.\""));

// ---------------------------------------------------------------------
// 12. Product Comparison (Task 7)
// ---------------------------------------------------------------------
sections.push(h1("12. Cross-Product Comparison"));
sections.push(p(
  "Adaptation note: CadetX's Task 7 brief assumes 4 team members each trained a separate " +
  "model. This solo submission has one shared model, so \"compare all four models\" is read as " +
  "\"compare all four products' features, sentiment, engagement, and the shared model's per-" +
  "product outputs.\""
));
sections.push(...img(`${A}/cadetx_task07_fig02_feature-radar-normalized.png`, 6.0, 3.4,
  "Fig. 6 — Normalized feature comparison across products."));
sections.push(...img(`${A}/cadetx_task07_fig01_readiness-vs-risk.png`, 5.0, 3.6,
  "Fig. 7 — Model readiness vs. risk-flag count, by product."));
sections.push(p("Universal predictors (low cross-product variation): mean_rating, review_volume_log1p, platform/source-type diversity."));
sections.push(p("Product-specific predictors (high variation): mean_lexicon_sentiment, engagement_per_signal, risk_flag_count, editorial_top_pick_count."));
sections.push(p(
  "Influencer impact could not be measured directly (no Twitter/X, Reddit, LinkedIn, or " +
  "YouTube API access — see §6); editorial/press authority was used as the closest available " +
  "proxy. On that proxy, Jasper leads on positive editorial endorsement while Rytr leads on " +
  "investigative press scrutiny — a meaningfully different, less favorable kind of attention."
));

// ---------------------------------------------------------------------
// 13. Product-Level Findings
// ---------------------------------------------------------------------
sections.push(h1("13. Product-Level Findings"));
sections.push(table(
  ["Product", "Rating", "Volume", "Sentiment lean", "Risk flags", "Notable finding"],
  [
    ["Jasper", "4.60 (lowest)", "1,269 reviews", "Positive", "0", "Only product with an editorial \"top pick\" mention and any discussion-thread engagement captured"],
    ["Copy.ai", "4.80 (highest)", "182-25,014 (source-dependent)", "Mixed", "1", "Cross-platform rating gap explicitly flagged by an independent roundup"],
    ["Writesonic", "4.70", "2,025-2,092 (largest single-source)", "Most positive lexicon score", "0", "Thinnest, most concentrated evidence base (4 signals, mostly aggregate ratings)"],
    ["Rytr", "4.65", "806-821 reviews", "Negative lean", "1", "Only product with a documented Trustpilot rating decline (4.9→4.5) tied to a review-quality penalty"],
  ],
  [1000, 1000, 1800, 1300, 900, 3360],
));

// ---------------------------------------------------------------------
// 14. Unified Product Launch Success Framework
// ---------------------------------------------------------------------
sections.push(h1("14. Unified Product-Launch Success Framework"));
sections.push(p(
  "The Launch Readiness Index (LRI) merges Task 5 features and the Task 6 model output into a " +
  "single, transparent score, using fixed absolute anchors (not within-sample min-max) so it " +
  "generalizes to a future, fifth product rather than only re-ranking these four."
));
sections.push(table(
  ["Component", "Weight", "Normalization anchor"],
  [
    ["Rating", "0.10", "Fixed 1-5 star scale"],
    ["Review volume", "0.20", "Fixed ceiling log1p(5000) reviews"],
    ["Sentiment", "0.20", "Fixed [-1,+1] scale rescaled to [0,1]"],
    ["Editorial endorsement", "0.15", "Fixed ceiling 1.5"],
    ["Engagement presence", "0.10", "Fixed ceiling 2.0 per signal"],
    ["Model-predicted readiness", "0.25", "Already a [0,1] probability — used directly"],
    ["Risk penalty (subtracted)", "-0.20", "Fixed ceiling 3 flags"],
  ],
  [3000, 1400, 4000],
));
sections.push(...img(`${A}/cadetx_task09_fig_lri-scores.png`, 5.8, 3.4,
  "Fig. 8 — Launch Readiness Index by product, with tier thresholds at 0.50 and 0.70."));
sections.push(p("Tiers: ≥0.70 Launch-Ready · 0.50-0.70 Launch with Monitoring · <0.50 Needs Remediation."));
sections.push(p(
  "Jasper's top score is driven by editorial endorsement and engagement presence — not rating, " +
  "which is actually the lowest of the four — direct evidence the framework isn't simply re-" +
  "deriving the rating ranking."
));

// ---------------------------------------------------------------------
// 15. Business Recommendations
// ---------------------------------------------------------------------
sections.push(h1("15. Business Recommendations"));
sections.push(bullet("Weight review-platform volume and engagement more heavily than star rating when assessing launch readiness in this genre — rating alone will not differentiate products."));
sections.push(bullet("Treat reputation-risk flags (cross-platform rating gaps, rating declines) as a hard penalty, not just a minor deduction — both flagged products (Copy.ai, Rytr) score meaningfully lower on the LRI."));
sections.push(bullet("Prioritize collecting discussion-thread/engagement data specifically — it is currently captured for only 1 of 4 products and was one of the strongest available differentiators where present (Jasper)."));
sections.push(bullet("Distinguish editorial endorsement from investigative press attention when tracking \"influencer impact\" — both are visible, but only one is favorable (Rytr's case)."));
sections.push(bullet("Before trusting the model-driven component of any future score, invest in closing the data-volume gap identified in Task 6 (ROC-AUC below 0.5) rather than adding more model complexity."));

// ---------------------------------------------------------------------
// 16. Limitations
// ---------------------------------------------------------------------
sections.push(h1("16. Limitations"));
sections.push(bullet("Sample size (29 signals, 4 products, 19 labelled rows) is small throughout — every statistic should be read as directional."));
sections.push(bullet("The Task 6 model's ROC-AUC is below the random-guessing baseline — it does not yet have real discriminative power, and it carries the single largest weight (0.25) in the Task 8 framework, a disclosed tension."));
sections.push(bullet("No authenticated social-media API access — the genre's real Twitter/X, Reddit, LinkedIn, and YouTube conversation (if any) is not represented."));
sections.push(bullet("Engagement data exists for only 1 of 4 products, so the engagement component of the LRI currently reads more as a data-collection artifact than a true product-level absence of engagement for the other three."));
sections.push(bullet("LRI anchors and tier thresholds are reasoned judgment calls informed by the observed data range, not statistically fit or validated against real launch outcomes."));

// ---------------------------------------------------------------------
// 17. Future Improvements
// ---------------------------------------------------------------------
sections.push(h1("17. Future Improvements"));
sections.push(bullet("Obtain authenticated API access (Twitter/X, Reddit, Product Hunt) to close the platform-coverage gap identified in Task 2."));
sections.push(bullet("Replace the rule-based favorable_signal_label with a real outcome variable (e.g. revenue tier, retained-user growth) if scoring products at/near actual launch."));
sections.push(bullet("Replace the hand-built sentiment lexicon with a sentiment model fit on a larger labelled text corpus."));
sections.push(bullet("Re-weight or rebuild the Task 6 model once more signal volume is available, before continuing to give it the largest weight in the LRI."));
sections.push(bullet("Validate LRI tier thresholds against actual post-launch outcomes once available, rather than the current reasoned-judgment starting split."));

// ---------------------------------------------------------------------
// 18. Conclusion
// ---------------------------------------------------------------------
sections.push(h1("18. Conclusion"));
sections.push(p(
  "This project delivers a complete, traceable pipeline from real, individually-sourced " +
  "social/market signals to a transparent, genre-generalizable Launch Readiness Index, built " +
  "and evaluated honestly at every stage — including reporting a model result (ROC-AUC below " +
  "0.5) that looks worse than the accuracy figure next to it, because that is what the evidence " +
  "actually showed. The framework is usable today for directional comparison within this genre " +
  "and is explicit about exactly what would need to improve — primarily sample size and " +
  "engagement-data coverage — before its model-driven component should be trusted at higher " +
  "stakes."
));

const doc = new Document({
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 } } },
    children: sections,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("cadetx_task09_final-report_v01.docx", buf);
  console.log("Report written.");
});
