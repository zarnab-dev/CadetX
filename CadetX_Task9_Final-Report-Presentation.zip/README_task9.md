# Task 9 — Final Report, Documentation & Presentation (CadetX, AI Writing Tools)

## What's in this folder
```
cadetx_task09_final-report_v01.docx          THE MAIN DELIVERABLE — 18-section report (see Task 9 brief's required sections)
cadetx_task09_final-presentation_v01.pptx    14-slide deck, following the CadetX-recommended narrative arc
docs/            All supporting documentation from Tasks 5-8, consolidated for the shared repo
report_assets/    Every chart embedded in the report/deck (Task 4, 7, and two new Task 9 charts)
build_report.js   Reproducible docx-generation script (docx / docx-js)
build_deck.js     Reproducible pptx-generation script (pptxgenjs)
```

## QA performed
- Report: rendered to PDF and visually inspected page-by-page; two tables that initially
  overflowed the page width were caught and fixed (column widths re-summed to fit US Letter
  margins).
- Deck: `validate.py` passed with no errors; rendered to images and visually inspected — no
  overflow, no leftover placeholder text (checked via `markitdown` + grep).

## How to reproduce
```
node build_report.js   # -> cadetx_task09_final-report_v01.docx
node build_deck.js     # -> cadetx_task09_final-presentation_v01.pptx
```
Requires: `docx` and `pptxgenjs` (npm, preinstalled in the CadetX build environment).

## Note on scope
This report/deck consolidates Tasks 1-8 as a single, solo-submitted body of work (see the
Task 1 project plan's "Team Setup Note" — this engagement covers all four specialist roles).
