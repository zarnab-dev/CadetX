# Task 7 — Cross-Product Comparison & Genre Insights (CadetX, AI Writing Tools)

## What's in this folder
```
data/         Task 5/6 inputs + Task 7's combined comparison table (the merge deliverable)
reports/      cadetx_task07_comparison-report_v01.md — THE MAIN DELIVERABLE:
              universal vs product-specific predictors, weak signals,
              influencer-impact proxy & its limitation, genre-wide insight
visualizations/  fig01 readiness-vs-risk quadrant, fig02 normalized feature comparison
src/          cadetx_task07_cross-product-comparison.py — reproducible script
```

## Adaptation note
CadetX's Task 7 brief assumes 4 team members each trained a separate model.
This solo submission has one shared model (Task 6), so "compare all four
models" is read as "compare all four products' features, sentiment,
engagement, and the shared model's per-product outputs" — see the report's
opening note for the full reasoning.

## How to reproduce
```
python3 src/cadetx_task07_cross-product-comparison.py
```
Requires: pandas, numpy, matplotlib.
