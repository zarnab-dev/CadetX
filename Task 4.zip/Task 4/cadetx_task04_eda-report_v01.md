# CadetX Task 04 — Exploratory Data Analysis Report

**Genre:** AI Writing Tools | **Products:** Jasper, Copy.ai, Writesonic, Rytr
**Input:** `data/cleaned/cadetx_task03_cleaned_all-products_v01.csv` (29 rows)
**Script:** `src/cadetx_task04_eda-analysis.py`
**Figures:** `visualizations/cadetx_task04_fig01…fig05`

## Sample-size disclosure (read this first)

This EDA is built on 29 real, individually-sourced signals across 4 products
(Jasper 9, Copy.ai 8, Writesonic 4, Rytr 8) — not a bulk API pull. Every
number below is real and traceable to a URL in the raw dataset, but n is
small, so patterns here are **directional observations for a first pass**,
not statistically robust conclusions. This gets addressed by widening
collection in a later iteration if the project continues past Task 4.

## Fig 1 — Signal count by product & source type
![fig1](../visualizations/cadetx_task04_fig01_signal-count-by-source-type.png)

**Observation:** Jasper and Rytr have the widest mix of source types
(aggregate ratings, individual reviews, discussion threads, editorial
roundups); Writesonic's signals are the most concentrated (mostly aggregate
ratings, fewer individual reviews or discussion threads turned up in search).
**Insight:** Writesonic's public conversation is thinner/less varied than its
review volume alone would suggest — worth flagging as a data-collection gap
to close in a real production version of this project (Task 2 iteration),
not just an EDA footnote.

## Fig 2 — Mean public review rating by product
![fig2](../visualizations/cadetx_task04_fig02_avg-rating-by-product.png)

**Observation:** All four products sit in a narrow 4.5–4.9 band — genre-wide,
these are all well-liked products by their own review-platform users. Copy.ai
has both the highest mean (4.80) and the widest spread (4.7–4.9 across
sources); Rytr has the lowest mean (4.65) and widest low end (down to 4.5,
driven by its Trustpilot penalty episode — see Fig 5 / data-source log).
**Insight:** Rating alone is a weak differentiator in this genre — everyone
scores well — so a launch-success model will need engagement/volume/
sentiment-stability signals more than raw star rating to discriminate between
products.

## Fig 3 — Largest reported review volume by product (log scale)
![fig3](../visualizations/cadetx_task04_fig03_review-volume-by-product.png)

**Observation:** Writesonic (2,092) and Jasper (1,269) have far larger review
footprints than Copy.ai (182, in the one head-to-head snapshot used here —
other sources report much higher, see limitation below) and Rytr (821).
**Insight:** Review-volume is a genuinely more discriminating signal than
rating for this genre and is a strong candidate "market traction" feature for
Task 5.
**Limitation carried from Task 2:** Copy.ai's review-count varies wildly by
source (182 to 25,014) depending on page scope; Fig 3 uses the most
directly-comparable snapshot (a head-to-head G2 compare page also used for
Writesonic) so the two are on equal footing, but this undercounts Copy.ai's
true footprint — noted so it isn't misread as "Copy.ai is the smallest."

## Fig 4 — Where each product's signals came from
![fig4](../visualizations/cadetx_task04_fig04_platform-mix-by-product.png)

**Observation:** G2 is the dominant source for every product except Rytr,
where editorial/press roundups dominate (5 of 8 signals) — largely because
Rytr's Trustpilot-penalty story attracted independent investigative coverage.
**Insight:** platform mix itself is a signal — a product attracting
investigative press coverage (Rytr) rather than just review-platform activity
may indicate a more contested reputation than its star rating alone shows.

## Fig 5 — Qualitative sentiment tags found, by product
![fig5](../visualizations/cadetx_task04_fig05_sentiment-tags-by-product.png)

**Observation:** Only a subset of rows carry an explicit sentiment tag from
their source (this is qualitative editorial framing, not a computed score).
Rytr is the only product with an explicitly negative-leaning tag in this
sample (tied to the Trustpilot rating-penalty story); Copy.ai has one
explicitly negative individual review ("highly underwhelmed") alongside
mostly positive framing elsewhere.
**Insight:** this is the thinnest, least reliable chart in this set — flagged
honestly rather than dressed up — because sentiment here is inherited from
how each source chose to frame its story, not independently measured. Task 5
should compute a proper sentiment score from `processed_text` instead of
relying on these inherited tags alone.

## Cross-cutting EDA insights (genre-level, feeding Task 7-8)

1. **Rating compresses, volume and press-attention spread out.** A launch
   framework for this genre should weight review-volume growth and
   editorial/press attention more heavily than star rating.
2. **Price positioning may correlate with review-platform mix.** Rytr (the
   cheapest, $9/mo) is the product most discussed by *independent
   investigative* reviewers rather than vendor-adjacent review platforms —
   worth testing as a feature (`price_tier` vs `source_type_diversity`) in
   Task 5/6.
3. **Data thinness is itself a genre finding.** None of the four established
   products in this genre had discoverable Product Hunt launch-day metrics or
   individually attributable Twitter/Reddit engagement data via search —
   this genre's real social conversation, at least for these four mature
   products, lives on B2B review platforms rather than the launch-hype
   platforms CadetX names first. That's a legitimate, reportable insight for
   the final framework, not just a limitation to apologize for.
