# CadetX Task 08 — Unified Genre-Level Success Framework
## The Launch Readiness Index (LRI) — AI Writing Tools genre

**Script:** `src/cadetx_task08_launch-readiness-index.py`
**Output:** `data/cadetx_task08_launch-readiness-scores_v01.csv`

## 1. What this framework answers

> Given social/market signals for a product in the AI Writing Tools genre,
> how launch-ready does it appear to be — using a transparent, reproducible
> score that can be computed the same way for a brand-new product?

## 2. Design principle: fixed anchors, not within-sample min-max

An earlier draft of this framework normalized every feature with min-max
scaling **across the 4 sampled products**. That was rejected and rebuilt,
for a concrete, disclosed reason: min-max across n=4 forces one product to
exactly 0 and one to exactly 1 on every single feature, no matter how close
together they actually are — and it silently breaks the moment a 5th,
future product needs scoring (Task 8 explicitly requires the framework to
evaluate *new* launches, not just re-rank these four). The final version
below uses **fixed, absolute anchors** chosen from domain-reasonable
ranges (documented per-feature), so a new product's raw score is
comparable to these four without recomputing anything.

## 3. Variables, normalization, and weights

| Variable | Raw source (Task 5/6) | Normalization anchor | Weight |
|---|---|---|---|
| Rating | `mean_rating` | Fixed 1–5 star scale: `(rating - 1) / 4` | 0.10 |
| Volume | `review_volume_log1p` | Fixed ceiling `log1p(5000)` reviews | 0.20 |
| Sentiment | Mean of `mean_explicit_sentiment` & `mean_lexicon_sentiment` | Fixed [-1,+1] scale rescaled to [0,1] | 0.20 |
| Editorial endorsement | `editorial_top_pick_count` + 0.25×(capped editorial mentions) | Fixed ceiling 1.5 | 0.15 |
| Engagement presence | `engagement_per_signal` | Fixed ceiling 2.0 (combined upvotes+comments per signal) | 0.10 |
| Model-predicted readiness | `mean_model_readiness` (Task 6) | Already a [0,1] probability — used directly | 0.25 |
| **Risk penalty** | `risk_flag_count` (cross-platform gap + Trustpilot decline) | Fixed ceiling 3 flags | **−0.20** |

**Formula:**
```
LRI = 0.10·rating_n + 0.20·volume_n + 0.20·sentiment_n + 0.15·editorial_n
      + 0.10·engagement_n + 0.25·model_readiness_n − 0.20·risk_n
LRI = clip(LRI, 0, 1)
```

### Why these weights
- **Model readiness gets the largest single weight (0.25)** because it is
  the only component that combines multiple signals simultaneously — but
  see §6: this weight should be revisited once the Task 6 model's ROC-AUC
  problem is fixed with more data, since a weak classifier is currently
  carrying the most influence in the formula.
- **Rating gets the smallest weight (0.10)** because Task 4 and Task 7 both
  independently found rating is a near-universal, weak differentiator in
  this genre — everyone scores 4.6–4.8, so it should not drive the ranking.
- **Volume and sentiment are weighted equally (0.20 each)** as the two
  strongest EDA-identified differentiators (Task 4 Figs 2–3).
- **Risk is a penalty, not a positive feature** — a product should not be
  able to "outscore" a real reputation-risk flag by being strong elsewhere;
  subtracting it (rather than treating "no risk" as just another positive
  input) keeps that non-negotiable.

## 4. Scores and tiers (this sample)

| Product | LRI | Tier |
|---|---|---|
| Jasper | **0.740** | Launch-Ready |
| Writesonic | 0.702 | Launch-Ready |
| Copy.ai | 0.556 | Launch with Monitoring |
| Rytr | 0.489 | Needs Remediation |

**Thresholds:**
- **≥ 0.70 — Launch-Ready:** strong across most components, no major
  unresolved risk flag.
- **0.50–0.70 — Launch with Monitoring:** viable but with at least one
  weak component (commonly: unresolved risk flag or below-anchor
  sentiment) that should be tracked post-launch, not treated as
  disqualifying.
- **< 0.50 — Needs Remediation:** either an unresolved risk flag combined
  with weak sentiment, or multiple components meaningfully below anchor.

Read alongside Task 7: Jasper's top score is driven by its unique editorial
top-pick and engagement presence in this sample, not by rating (its rating
is actually the *lowest* of the four) — direct evidence that this framework
is not just re-deriving the rating ranking, which is the whole point of it.

## 5. How to score a new (5th) product in this genre

1. Collect the same signal types as Task 2 (ratings, review counts,
   sentiment tags/text, momentum/editorial mentions, risk flags) for the
   new product, following the Task 2/3 pipeline.
2. Run it through Task 5's feature engineering script to get the same
   product-level feature row.
3. Score it with the Task 6 model (`models/cadetx_task06_*.joblib`) to get
   its `mean_model_readiness`.
4. Apply the fixed anchors and formula above — no recomputation of anchors
   against the other 4 products is needed, by design.
5. Read the resulting tier, then check *which* component pulled the score
   down (the CSV keeps every normalized sub-score, not just the final
   number) before treating the tier as a final verdict.

## 6. Limitations (explicit)

- **The 0.25 weight on `model_readiness_n` is inheriting Task 6's disclosed
  weakness** — that model's ROC-AUC was below 0.5 on LOOCV, meaning it does
  not yet discriminate favorable from unfavorable signals better than
  chance. This framework currently gives that component the *most* weight
  of any single input, which is a real tension: it is the most
  "sophisticated"-looking input and also the least statistically validated
  one. Flagged here rather than hidden — a future iteration should either
  lower this weight or fix the underlying model first.
- **Anchors are reasoned, not fit or empirically derived from a large
  reference population** (e.g., the log1p(5000)-review ceiling is a
  judgment call informed by this genre's observed 182–25,014 range, not a
  statistically optimized cutoff). They should be revisited once more
  genre data exists.
- **n=4 products** means the tier boundaries (0.50 / 0.70) have not been
  validated against any actual launch outcome — they are a reasonable
  starting split given the observed 0.489–0.740 score range, not a
  calibrated decision threshold.
- **Engagement data exists for only 1 of 4 products** (Jasper) in this
  sample — the `engagement_n` component will read as 0 for any product
  with no captured discussion-thread data, which penalizes thin *data
  collection* as if it were thin *actual* engagement. This is flagged as a
  measurement-vs-reality gap, not resolved, in this version.
