# Task 8 — Unified Genre-Level Success Framework (CadetX, AI Writing Tools)

## What's in this folder
```
data/    Task 5/6 inputs + cadetx_task08_launch-readiness-scores_v01.csv (scored output)
docs/    cadetx_task08_framework-document_v01.md — THE MAIN DELIVERABLE:
         scoring method, weights, normalization anchors, thresholds, tiers,
         how to evaluate a new product, and explicit limitations
src/     cadetx_task08_launch-readiness-index.py — reference implementation
```

## Headline result
| Product | Launch Readiness Index | Tier |
|---|---|---|
| Jasper | 0.740 | Launch-Ready |
| Writesonic | 0.702 | Launch-Ready |
| Copy.ai | 0.556 | Launch with Monitoring |
| Rytr | 0.489 | Needs Remediation |

## Why fixed anchors, not min-max across the 4 products
Min-max across only 4 products would force one to 0 and one to 1 on every
feature regardless of real closeness, and would break the moment a 5th
product needed scoring. This framework uses fixed, documented anchors
(1–5 rating scale, log1p(5000)-review ceiling, etc.) instead — see §2–3 of
the framework document for the full reasoning and a worked "how to score a
new product" walkthrough (§5).

## How to reproduce
```
python3 src/cadetx_task08_launch-readiness-index.py
```
Requires: pandas, numpy.
