"""
CadetX Task 08 — Unified Genre-Level Success Framework
Genre: AI Writing Tools | Products: Jasper, Copy.ai, Writesonic, Rytr

Input : data/cadetx_task05_product-level-features_v01.csv
        data/cadetx_task06_product-level-predicted-readiness_v01.csv
Output: data/cadetx_task08_launch-readiness-scores_v01.csv

Builds the Launch Readiness Index (LRI) defined in
docs/cadetx_task08_framework-document_v01.md. This script is the reference
implementation — the formula, weights, and normalization rule are defined
in the framework document; this file must match it exactly.
"""

import numpy as np
import pandas as pd

prod = pd.read_csv("data/cadetx_task05_product-level-features_v01.csv")
readiness = pd.read_csv("data/cadetx_task06_product-level-predicted-readiness_v01.csv")
df = prod.merge(readiness[["product", "mean_model_readiness"]], on="product")


# ---------------------------------------------------------------------------
# Normalize each raw component to [0,1] using FIXED, ABSOLUTE anchors — not
# within-sample min-max. This is deliberate: min-max across only 4 products
# would force one product to 0 and one to 1 on every feature regardless of
# how close together they actually are, and would silently BREAK the moment
# a 5th, future product is scored (Task 8 explicitly requires the framework
# to evaluate new launches, not just re-rank these four). Every anchor below
# is documented in the framework doc so it can be sanity-checked or revised.
# ---------------------------------------------------------------------------
df["sentiment_raw"] = df[["mean_explicit_sentiment", "mean_lexicon_sentiment"]].mean(axis=1, skipna=True)
df["editorial_raw"] = df["editorial_top_pick_count"] + df["editorial_review_count"].clip(upper=2) * 0.25

norm = pd.DataFrame({"product": df["product"]})
# Rating: fixed 1-5 star-rating scale (the scale review platforms actually use).
norm["rating_n"] = ((df["mean_rating"] - 1) / 4).clip(0, 1)
# Volume: log1p(review_count) against a fixed ceiling of log1p(5000) reviews
# ("mature, high-traction product" anchor for this genre) — chosen from the
# observed range (182-25,014 raw reviews across the 4 products, see Task 4),
# not fit to make these 4 products look any particular way.
norm["volume_n"] = (df["review_volume_log1p"] / np.log1p(5000)).clip(0, 1)
# Sentiment: raw score already lives on a fixed [-1, +1] scale (Task 5) -> rescale to [0,1].
norm["sentiment_n"] = ((df["sentiment_raw"].fillna(0) + 1) / 2).clip(0, 1)
# Editorial: fixed ceiling of 1.5 (1 top-pick + 2 editorial mentions at 0.25 each).
norm["editorial_n"] = (df["editorial_raw"] / 1.5).clip(0, 1)
# Engagement: fixed ceiling of 2.0 combined upvotes+comments per signal.
norm["engagement_n"] = (df["engagement_per_signal"] / 2.0).clip(0, 1)
# Model readiness: Task 6 output is ALREADY a probability in [0,1] — used
# directly, not re-normalized (re-normalizing a bounded probability across
# only 4 products would distort it exactly the way min-max distorts the rest).
norm["model_readiness_n"] = df["mean_model_readiness"].clip(0, 1)
# Risk penalty: fixed cap of 3 flags, so the score stays comparable if a
# future product has more risk flags than any of these four.
norm["risk_n"] = (df["risk_flag_count"].clip(upper=3) / 3.0)

# ---------------------------------------------------------------------------
# Weighted composite — weights defined in the framework document
# ---------------------------------------------------------------------------
WEIGHTS = {
    "rating_n": 0.10,
    "volume_n": 0.20,
    "sentiment_n": 0.20,
    "editorial_n": 0.15,
    "engagement_n": 0.10,
    "model_readiness_n": 0.25,
}
RISK_WEIGHT = 0.20

positive = sum(norm[k] * w for k, w in WEIGHTS.items())
norm["launch_readiness_index"] = (positive - RISK_WEIGHT * norm["risk_n"]).clip(0, 1)


def tier(score):
    if score >= 0.70:
        return "Launch-Ready"
    if score >= 0.50:
        return "Launch with Monitoring"
    return "Needs Remediation"


norm["tier"] = norm["launch_readiness_index"].apply(tier)
norm = norm.sort_values("launch_readiness_index", ascending=False).reset_index(drop=True)

out_cols = ["product", "rating_n", "volume_n", "sentiment_n", "editorial_n",
            "engagement_n", "model_readiness_n", "risk_n", "launch_readiness_index", "tier"]
norm[out_cols].to_csv("data/cadetx_task08_launch-readiness-scores_v01.csv", index=False)

print(norm[out_cols].to_string(index=False))
