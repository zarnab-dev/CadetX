# CadetX Task 10 — Individual Reflection

*Written from the perspective of the analyst who completed all four specialist roles for
this solo engagement (see Task 1 "Team Setup Note"). This reflects on the actual decisions
made across Tasks 1-9 in this session, not a fabricated narrative.*

## What this project actually tested

Going in, the interesting question wasn't really "can a model predict launch success" —
with 4 products and 29 signals, no model was ever going to do that convincingly. The real
test was whether the *pipeline* could stay honest under that constraint: collect only real
data, say clearly when a number is missing rather than filling it in, and report a bad
result (the Task 6 AUC) as prominently as a good one (the Task 6 accuracy).

## A mistake I caught, and what it taught me

The first version of the Task 8 Launch Readiness Index used min-max normalization across
the 4 sampled products. It produced a *plausible-looking* table — every score fell neatly
between 0 and 1 — until I actually asked "what happens if a 5th product comes in with a
better volume than all four of these?" The answer was: the formula would need to be
rebuilt from scratch, because min-max is relative to whatever's currently in the sample.
That's a real design flaw for a framework whose entire stated purpose (per the CadetX
brief) is evaluating *new* launches. Rebuilding it with fixed, reasoned anchors instead —
and writing down *why* the first version was wrong, not just quietly swapping it — felt
like the more useful deliverable than either version alone would have been.

## Where I chose to under-deliver on purpose

Task 6 asks for a trained model with accuracy/F1/RMSE/AUC. It would have been easy to
report only accuracy and F1 (both look fine, 0.68-0.85) and let that carry the slide. I
chose to lead with the AUC number instead, because it's the metric that actually tells you
whether the model is doing something real, and here it says it isn't (0.19-0.26, below
chance). That's a less satisfying deliverable than a clean "model achieves 74% accuracy"
headline — but it's the honest one, and downstream tasks (7, 8) had to actually account
for that weakness rather than build on top of an inflated result.

## Where the "solo covering four roles" framing mattered

Tasks 7 and 9 both explicitly assume a 4-person team ("compare all four models," "each
member writes a reflection"). Rather than silently reinterpreting those instructions or
fabricating four team members' worth of output, I stated the adaptation openly each time
(Task 7's opening note, this document) and adjusted the deliverable to what a single
analyst covering all four roles can actually produce truthfully — one shared model, one
reflection, not four faked ones.

## What I'd do differently with more time or data

- Push harder on Task 2 to find *any* legitimate Twitter/X or Reddit signal before
  concluding the platform gap was unresolvable — I stopped at "no authenticated API
  access," which was true, but a more thorough pass might have found public, non-API
  discussion data I didn't try hard enough to locate.
- Revisit the Task 8 weight on model-predicted readiness (0.25, the largest single
  weight) given the Task 6 AUC finding — I flagged this tension explicitly rather than
  resolving it, and a longer engagement should resolve it rather than just disclose it.

## Overall

The project produces a smaller, less impressive-looking result than a version that
smoothed over its weak points would — a genre-level model that doesn't yet discriminate
better than chance, a 4-product sample too small to statistically validate anything, and a
framework built on judgment calls rather than fitted parameters. I think that's the right
trade for this kind of work: the honest version is more useful to whoever picks this up
next than a polished one that hides where it's actually thin.
