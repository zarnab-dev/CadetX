# CadetX Task 10 — Final Quality Audit

Performed as an independent, adversarial self-review against the CadetX evaluator's
checklist (project brief §23), since no live mentor session was available in this
environment — see "Note on the mentor walkthrough" at the end of this document for how
that adaptation was handled honestly.

## Audit checklist

| Check | Result | Notes |
|---|---|---|
| All 10 tasks completed | ✅ | Tasks 1-10 all have a concrete deliverable, listed below |
| All required deliverables created | ✅ | Cross-checked against each task's "EACH MEMBER SUBMITS" / "TEAM SUBMITS" line — see table below |
| Correct task sequence | ✅ | Completed in batches of 2, in order, with explicit user confirmation between each batch |
| Product Launch focus maintained | ✅ | Every task ties back to the launch-readiness question; Task 8's LRI is the explicit synthesis point |
| Data consistency | ✅ | Row counts verified at each handoff (29 raw → 29 cleaned → 29 signal-level features → 19 labelled for modelling → 4 products throughout); no silent drops |
| Calculation accuracy | ✅ (1 issue found & fixed) | Task 8's first LRI draft used within-sample min-max normalization, which was caught during self-review as unsound (would break on a 5th product) and rebuilt with fixed anchors before delivery |
| Visualization accuracy | ✅ (2 issues found & fixed) | Two Task 9 report tables initially overflowed page margins; caught in PDF-rendered visual QA and fixed by resizing columns before delivery |
| Model validity | ⚠️ Disclosed, not hidden | Task 6 model's ROC-AUC (0.19-0.26) is below the random-guessing baseline — reported as the headline finding rather than downplayed |
| No obvious data leakage | ✅ | Task 6 explicitly excludes rating/sentiment/momentum columns that constructed the label from the model's feature set (documented in Task 5 "Leakage check") |
| Sources documented | ✅ | Every signal traces to a real URL in the Task 2 data-source log |
| Claims evidence-based | ✅ | No claim in the final report lacks a traceable source in an earlier task's output |
| Limitations disclosed | ✅ | Each task's doc has an explicit Limitations section; consolidated in the final report §16 |
| Report matches analysis | ✅ | Every number in the Task 9 report was re-pulled from the actual Task 5-8 output files, not retyped from memory |
| Presentation matches findings | ✅ | Same source figures/tables reused across report and deck — no divergent numbers |
| Framework is logically derived | ✅ | Task 8 weights are justified against Task 4/7 findings (e.g., rating down-weighted because both tasks independently found it a weak differentiator) |
| Repository is organized | ✅ | Consolidated into `data/src/models/visualizations/reports/docs/presentation` structure (Task 10 deliverable) |
| Evaluation criteria satisfied | ✅ | See per-task deliverable table below |

## Deliverables cross-check (per task)

| Task | Required deliverable | Delivered as |
|---|---|---|
| 1 | Chosen product & genre + justification | `reports/cadetx_task01_project-plan_v01.docx` |
| 2 | Raw social-signal dataset | `data/raw/cadetx_task02_raw_all-products_2026-09-08.csv` + data-source log |
| 3 | Cleaned dataset + preprocessing note | `data/cleaned/…csv` + `reports/cadetx_task03_preprocessing-notes_v01.md` |
| 4 | EDA report + shared visuals | `reports/cadetx_task04_eda-report_v01.md` + `visualizations/cadetx_task04_fig*.png` |
| 5 | Feature-engineered dataset + explanation | `data/processed/cadetx_task05_*.csv` + `docs/cadetx_task05_feature-dictionary_v01.md` |
| 6 | Trained model + metrics + explanation | `models/*.joblib` + `docs/cadetx_task06_model-metrics_v01.md` |
| 7 | Combined cross-product comparison report | `docs/cadetx_task07_comparison-report_v01.md` + 2 figures |
| 8 | Consolidated framework document | `docs/cadetx_task08_framework-document_v01.md` |
| 9 | Final report + slide deck | `reports/cadetx_task09_final-report_v01.docx` + `presentation/cadetx_task09_final-presentation_v01.pptx` |
| 10 | Repo link + report/deck + mentor notes + reflection | This document + `cadetx_task10_reflection_v01.md` + consolidated `repo/` (see note below on the GitHub link) |

## Weaknesses identified and how they were handled

1. **Task 8 normalization flaw (caught before delivery).** The first LRI draft min-max
   normalized every feature across only the 4 sampled products. This was rejected during
   self-review because it would force one product to score exactly 0 and another exactly
   1 on every feature regardless of real closeness, and would break the moment a 5th
   product needed scoring. Rebuilt with fixed, absolute anchors instead — documented in
   the Task 8 framework doc §2 as a design decision, not silently corrected.
2. **Task 9 table overflow (caught before delivery).** Two report tables were sized wider
   than the US Letter page margins in the first render; caught during required visual PDF
   QA and fixed by resizing columns.
3. **Task 6 model weakness (disclosed, not a defect to "fix" by hiding it).** The
   ROC-AUC-below-chance result is a genuine finding given the sample size, not a bug —
   it is reported prominently rather than fixed by, e.g., quietly switching to a metric
   that looks better.
4. **Engagement-data sparsity (disclosed, unresolved).** Only 1 of 4 products has any
   discussion-thread engagement data. This was not "fixed" by imputing or fabricating
   engagement numbers for the other three — it remains a stated limitation throughout
   Tasks 5-9.

## Note on the mentor walkthrough

CadetX Task 10 calls for walking the project through with a mentor and recording their
feedback. No live mentor was available in this solo, single-session engagement. Rather
than fabricate mentor quotes or feedback attributed to a person who did not review this
work, this audit was conducted as a structured, adversarial self-review against the
project's own stated evaluation criteria (§23 of the brief) — the closest honest
substitute available. Anything a mentor would plausibly flag is captured in the
"Weaknesses identified" section above and in each task's own Limitations section, rather
than smoothed over.
