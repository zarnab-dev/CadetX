"""
CadetX Task 07 — Cross-Product Comparison & Genre Insights
Genre: AI Writing Tools | Products: Jasper, Copy.ai, Writesonic, Rytr

Input : data/cadetx_task05_product-level-features_v01.csv   (Task 5, n=4)
        data/cadetx_task05_signal-level-features_v01.csv    (Task 5, n=29)
        data/cadetx_task06_product-level-predicted-readiness_v01.csv (Task 6)
        data/cadetx_task06_signal-level-predictions_v01.csv (Task 6)
Output: data/cadetx_task07_combined-comparison-table_v01.csv
        visualizations/cadetx_task07_fig01_readiness-vs-risk.png
        visualizations/cadetx_task07_fig02_feature-radar-normalized.png

Adaptation note: CadetX's Task 7 brief ("compare all four models") assumes
a 4-person team where each member independently modelled their own product.
This is a solo submission with ONE shared model trained on all 29 signals
(Task 6) rather than 4 separate per-product models — so "compare all four
models" is read here as "compare all four PRODUCTS' features, sentiment,
engagement, and shared-model outputs" — the equivalent comparison a solo
build can actually support without fabricating four models that don't
exist.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

prod = pd.read_csv("data/cadetx_task05_product-level-features_v01.csv")
readiness = pd.read_csv("data/cadetx_task06_product-level-predicted-readiness_v01.csv")
sig = pd.read_csv("data/cadetx_task05_signal-level-features_v01.csv")
sig_pred = pd.read_csv("data/cadetx_task06_signal-level-predictions_v01.csv")

combined = prod.merge(readiness[["product", "mean_logreg_readiness", "mean_rf_readiness", "mean_model_readiness"]], on="product")
combined = combined.sort_values("mean_model_readiness", ascending=False).reset_index(drop=True)
combined.to_csv("data/cadetx_task07_combined-comparison-table_v01.csv", index=False)

print("=== Combined per-product comparison table ===")
cols_show = [
    "product", "n_signals", "mean_rating", "review_volume_log1p",
    "mean_explicit_sentiment", "mean_lexicon_sentiment",
    "engagement_per_signal", "risk_flag_count", "editorial_top_pick_count",
    "mean_model_readiness",
]
print(combined[cols_show].to_string(index=False))

# ---------------------------------------------------------------------------
# Universal vs product-specific predictors
# ---------------------------------------------------------------------------
# "Universal": features whose sign/direction is consistent across all four
# products relative to the genre median (i.e. everyone in the genre is
# moving the same way on it). "Product-specific": features where one
# product is a clear outlier vs the other three.

check_features = [
    "mean_rating", "review_volume_log1p", "mean_lexicon_sentiment",
    "engagement_per_signal", "risk_flag_count", "editorial_top_pick_count",
    "platform_diversity_ratio", "source_type_diversity_ratio",
]

genre_median = combined[check_features].median()
spread = combined[check_features].std() / (combined[check_features].mean().abs() + 1e-9)

universal, product_specific = [], []
for f in check_features:
    cv = spread[f]  # coefficient of variation across the 4 products
    if cv < 0.25:
        universal.append(f)
    elif cv > 0.75:
        product_specific.append(f)

print("\nUniversal (low cross-product variation, CV<0.25):", universal)
print("Product-specific (high cross-product variation, CV>0.75):", product_specific)

# ---------------------------------------------------------------------------
# Weak signals: features with ~zero importance in BOTH Task 6 models
# (hard-coded from Task 6 output, cited here rather than recomputed to
# avoid re-deriving a different number by accident)
# ---------------------------------------------------------------------------
weak_signals = ["engagement_total", "is_discussion_thread", "has_engagement"]
print("\nWeak signals (near-zero importance in both Task 6 models):", weak_signals)

# ---------------------------------------------------------------------------
# Fig 1 — Readiness score vs risk-flag count (positioning quadrant chart)
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7, 5))
ax.scatter(combined["risk_flag_count"], combined["mean_model_readiness"], s=200, color="#2b6cb0", zorder=3)
for _, row in combined.iterrows():
    ax.annotate(row["product"], (row["risk_flag_count"], row["mean_model_readiness"]),
                textcoords="offset points", xytext=(8, 8), fontsize=11)
ax.axhline(combined["mean_model_readiness"].median(), color="grey", linestyle="--", linewidth=0.8)
ax.axvline(combined["risk_flag_count"].median(), color="grey", linestyle="--", linewidth=0.8)
ax.set_xlabel("Risk-flag count (cross-platform gap + Trustpilot decline)")
ax.set_ylabel("Mean model-predicted readiness score")
ax.set_title("AI Writing Tools genre: readiness vs. risk, by product")
fig.tight_layout()
fig.savefig("visualizations/cadetx_task07_fig01_readiness-vs-risk.png", dpi=150)
plt.close(fig)

# ---------------------------------------------------------------------------
# Fig 2 — Normalized feature radar/bar comparison across products
# ---------------------------------------------------------------------------
radar_features = ["mean_rating", "review_volume_log1p", "mean_lexicon_sentiment", "engagement_per_signal", "mean_model_readiness"]
norm = combined.set_index("product")[radar_features].copy()
norm = (norm - norm.min()) / (norm.max() - norm.min() + 1e-9)

fig, ax = plt.subplots(figsize=(9, 5))
x = np.arange(len(radar_features))
width = 0.2
for i, p in enumerate(norm.index):
    ax.bar(x + i * width, norm.loc[p].values, width=width, label=p)
ax.set_xticks(x + width * 1.5)
ax.set_xticklabels(radar_features, rotation=20, ha="right")
ax.set_ylabel("Normalized value (0-1, min-max across the 4 products)")
ax.set_title("Normalized feature comparison across products (AI Writing Tools)")
ax.legend()
fig.tight_layout()
fig.savefig("visualizations/cadetx_task07_fig02_feature-radar-normalized.png", dpi=150)
plt.close(fig)

print("\nFigures written to visualizations/.")
