# CadetX — Product Launch Analytics: AI Writing Tools Genre

**Genre:** AI Writing Tools | **Products:** Jasper, Copy.ai, Writesonic, Rytr
**Submission mode:** Solo — one analyst covering all four CadetX specialist roles
(see `reports/cadetx_task01_project-plan_v01.docx`, "Team Setup Note")

## Project purpose & problem

Given public social/market signals about a product, how launch-ready does it appear to
be — and which signals generalize across a genre versus which are product-specific? This
repository answers that question for four AI writing-tool products chosen to stress-test
it: they differ in price ($9–69+/mo), positioning, and review-platform profile.

## Repository structure

```
data/
  raw/         Task 2 raw collected signals (29 rows, real sources — see data-source log)
  cleaned/     Task 3 cleaned/normalized dataset
  processed/   Task 5-8 feature tables, model predictions, comparison table, LRI scores
src/           All reproducible pipeline scripts (Task 2, 5, 6, 7, 8)
models/        Trained Task 6 models (LogisticRegression, RandomForest — joblib)
visualizations/  Every chart produced across Tasks 4, 7, 9
reports/       Task 1 project plan, Task 2 data-source log, Task 3 preprocessing notes,
               Task 4 EDA report, Task 9 final report (.docx)
docs/          Task 5 feature dictionary, Task 6 model metrics, Task 7 comparison report,
               Task 8 framework document
presentation/  Task 9 final slide deck (.pptx)
```

## Methodology summary

1. **Task 1-2:** Selected the AI Writing Tools genre and 4 products; collected 29 real
   signals from public review platforms and editorial coverage (no social-media API
   access was available — disclosed, not fabricated around).
2. **Task 3:** Cleaned and normalized into a reproducible pipeline.
3. **Task 4:** EDA found rating is a weak, near-universal differentiator; volume and
   platform mix are more informative.
4. **Task 5:** Engineered signal-level (n=29) and product-level (n=4) feature tables.
5. **Task 6:** Trained Logistic Regression / Random Forest on a documented, rule-based
   "favorable signal" label; LOOCV evaluation found reasonable accuracy but ROC-AUC below
   the random-guessing baseline — reported as the headline honest finding.
6. **Task 7:** Compared all four products; found universal vs. product-specific
   predictors and a disclosed limitation on measuring "influencer impact."
7. **Task 8:** Built the Launch Readiness Index (LRI) — a transparent, fixed-anchor
   composite score generalizable to future products, not just these four.
8. **Task 9:** Consolidated everything into a final report (.docx) and slide deck (.pptx).
9. **Task 10:** Final self-audit, reflection, and this repository consolidation.

## Major findings

- Star rating (4.6–4.8 across all four) barely differentiates this genre.
- Reputation-risk flags and discussion-engagement presence are the strongest available
  differentiators, though both are unevenly measured across products.
- The Task 6 model's ROC-AUC (0.19–0.26) is below chance — a genuine small-n/class-
  imbalance finding, disclosed rather than hidden behind a better-looking accuracy figure.
- Launch Readiness Index ranking: Jasper (0.740, Launch-Ready) > Writesonic (0.702,
  Launch-Ready) > Copy.ai (0.556, Monitoring) > Rytr (0.489, Needs Remediation).

## Launch Readiness Index — quick reference

See `docs/cadetx_task08_framework-document_v01.md` for the full formula, weights, and
worked example of scoring a new (5th) product in this genre.

## Reproduction

```
pip install pandas numpy scikit-learn joblib matplotlib --break-system-packages
python3 src/cadetx_task05_feature-engineering.py
python3 src/cadetx_task06_prediction-model.py
python3 src/cadetx_task07_cross-product-comparison.py
python3 src/cadetx_task08_launch-readiness-index.py
```
Each script reads the previous task's output from `data/processed/` — run in the order above.

## Limitations (see individual task docs for full detail)

- Sample size is small throughout (29 signals, 4 products) — every statistic is directional.
- No authenticated Twitter/X, Reddit, LinkedIn, or YouTube API access in this environment.
- The Task 6 model does not yet discriminate better than chance (ROC-AUC < 0.5), despite
  carrying the largest single weight (0.25) in the Task 8 framework — a disclosed tension.
- Engagement data exists for only 1 of 4 products — an availability gap, not a proven
  real-world absence of engagement for the other three.

## GitHub publishing note

This repository was assembled and validated locally in the CadetX build environment. No
GitHub account or push credentials are available here, so no repository URL is provided —
fabricating one would violate the project's no-fabrication rule. To publish: create a new
GitHub repo, copy this folder's contents in, and commit. See Task 10 documentation for the
full note on this adaptation.
