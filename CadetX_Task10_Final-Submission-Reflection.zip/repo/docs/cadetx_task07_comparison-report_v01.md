# CadetX Task 07 — Cross-Product Comparison & Genre Insights

**Genre:** AI Writing Tools | **Products:** Jasper, Copy.ai, Writesonic, Rytr
**Inputs:** Task 5 product/signal feature tables, Task 6 model outputs
**Script:** `src/cadetx_task07_cross-product-comparison.py`
**Figures:** `visualizations/cadetx_task07_fig01…02`

## Adaptation note (read first)

CadetX's Task 7 brief assumes a 4-person team where each member trained a
separate model for their own product ("compare all four models"). This is
a solo submission with **one shared model trained on all 29 signals**
(Task 6), not four independent models. So this comparison is read as its
closest honest equivalent: **compare all four PRODUCTS** on features,
sentiment, engagement, and the shared model's per-product outputs — the
comparison a single build can actually support without fabricating four
models that don't exist.

## Combined comparison table

| Product | Signals | Mean rating | Review volume (log) | Lexicon sentiment | Engagement/signal | Risk flags | Editorial top-pick | Model readiness |
|---|---|---|---|---|---|---|---|---|
| Writesonic | 4 | 4.70 | 7.65 | **0.75** | 0.00 | 0 | 0 | **0.818** |
| Copy.ai | 8 | **4.80** | **10.13** | 0.13 | 0.00 | 1 | 0 | 0.737 |
| Jasper | 9 | 4.60 | 7.15 | 0.22 | **0.78** | 0 | **1** | 0.679 |
| Rytr | 8 | 4.65 | 6.71 | -0.13 | 0.00 | 1 | 0 | 0.676 |

(Full machine-readable version: `data/cadetx_task07_combined-comparison-table_v01.csv`)

## Universal predictors (consistent across all 4 products)

Measured as **low cross-product coefficient of variation (CV < 0.25)** on
the genre-level features:

- **`mean_rating`** — all four sit in a narrow 4.60–4.80 band (confirms the
  Task 4 EDA finding: rating barely differentiates products in this genre).
- **`review_volume_log1p`** — all four have a broadly comparable order-of-
  magnitude review footprint once log-scaled (raw counts vary more, but the
  *log-scaled* signal is comparatively stable — a methodological finding,
  not just a business one).
- **`platform_diversity_ratio`, `source_type_diversity_ratio`** — all four
  products' signals were sourced from a similarly diverse mix of platforms/
  source types, i.e. no product's evidence base is dramatically thinner in
  *kind* (though it does vary in *volume* — see Writesonic, n=4 signals vs
  Jasper, n=9).

**Genre-wide takeaway:** rating and platform-diversity are present across
the whole genre but do not discriminate between products — consistent with
Task 6's finding that `has_rating` carried modest, not dominant, importance.

## Product-specific predictors (high variation, CV > 0.75)

- **`mean_lexicon_sentiment`** — ranges from -0.13 (Rytr) to +0.75
  (Writesonic). Writesonic's small (n=4), concentrated signal set happens
  to skew positive; Rytr is the only product with a negative mean, driven
  by its Trustpilot-decline story (Task 4 Fig 5).
- **`engagement_per_signal`** — Jasper (0.78) is the only product with any
  discussion-thread engagement at all in this dataset; the other three are
  exactly 0. This is a genuine product-specific pattern, not noise — Jasper
  is the only one of the four with G2 Discussion threads captured in
  collection.
- **`risk_flag_count`** — Copy.ai and Rytr each carry 1 risk flag
  (cross-platform gap; Trustpilot decline respectively); Jasper and
  Writesonic carry 0.
- **`editorial_top_pick_count`** — only Jasper has an explicit "top pick"
  editorial mention in this sample.

**Genre-wide takeaway:** once rating is controlled for, the signals that
actually separate these products are *reputation-risk flags* and
*discussion-engagement presence*, not review volume or star rating — this
directly supports weighting risk flags and engagement presence, not just
rating, in the Task 8 framework.

## Influencer impact

**Disclosed limitation, not fabricated:** no individually-attributable
influencer-account data (follower-weighted mentions, verified-account
activity, etc.) was available for these four products in this environment
(see Task 2 data-source log — no Twitter/X, Reddit, LinkedIn, or YouTube
API access). The closest available proxy is **editorial/press authority**
— independent editorial roundups and investigative reviews acting as the
genre's actual visible "influencer" layer (Task 4 Fig 4). On that proxy:
Jasper has the most editorial endorsement weight (1 top-pick + 2 editorial
reviews); Rytr has the most *investigative* press attention (driven by its
Trustpilot story) — attention that is high-visibility but not favorable.
This distinction — editorial endorsement vs. investigative scrutiny — is
itself a genre-level insight, not a single "influencer impact" number.

## Weak signals (near-zero importance in the Task 6 model)

`engagement_total`, `is_discussion_thread`, and `has_engagement` all had
~0 importance in both the Logistic Regression and Random Forest models
(Task 6 §5). This is consistent with the product-specific finding above:
engagement data exists for only 1 of 4 products (Jasper), so the model
correctly learned it isn't a generalizable genre-wide predictor — it's a
Jasper-specific data-availability artifact, not evidence that engagement
doesn't matter in general.

## Genre-wide insight, stated plainly

For this specific genre (AI Writing Tools) and this dataset: **rating is a
near-universal, weak differentiator; reputation-risk flags and the
presence/absence of discussion-thread engagement are the strongest
differentiators available, but both are unevenly measured across products**
(engagement data exists for only 1 of 4 products; risk flags for only 2 of
4). This unevenness is itself the headline genre-level finding carried into
Task 8: a genre-level scoring framework must handle missing evidence
gracefully rather than assume every product will have every signal type.
