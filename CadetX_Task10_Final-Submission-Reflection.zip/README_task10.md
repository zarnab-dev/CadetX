# Task 10 — Final Submission, Review & Reflection (CadetX, AI Writing Tools)

## What's in this folder
```
docs/    cadetx_task10_final-quality-audit_v01.md — checklist audit against CadetX's
         own §23 evaluator criteria, deliverable cross-check, and weaknesses found/fixed
         cadetx_task10_reflection_v01.md — individual reflection on the actual decisions
         made across Tasks 1-9 (see note below on the "4-person team" adaptation)
repo/    THE FULL CONSOLIDATED PROJECT REPOSITORY (Tasks 1-9 outputs, organized) — see
         repo/README.md for structure, methodology summary, and findings
```

## What's adapted, and why (read before treating anything as missing)

- **No GitHub repository link is provided.** This environment has no GitHub account or
  push credentials. Fabricating a URL would violate the project's core no-fabrication
  rule, so `repo/` is delivered as a ready-to-push local folder instead, with instructions
  in `repo/README.md`.
- **No mentor feedback notes are included as such.** No live mentor session occurred in
  this solo, single-session engagement. In its place, `cadetx_task10_final-quality-audit_v01.md`
  is a structured, adversarial self-review against CadetX's own evaluation checklist —
  the closest honest substitute, and it says so explicitly rather than presenting itself
  as mentor feedback.
- **One reflection, not four.** Tasks 7-10 assume a 4-person team; this is a solo
  engagement covering all four specialist roles (per Task 1's "Team Setup Note"), so one
  honest reflection is provided rather than four fabricated ones.

## Headline result of the audit
All 10 tasks completed with their required deliverables; two real issues were caught and
fixed before delivery (an unsound Task 8 normalization approach; two overflowing Task 9
report tables); one finding is disclosed rather than fixed because it's real, not a bug
(the Task 6 model's below-chance ROC-AUC, which still carries the largest single weight in
the Task 8 framework — flagged as an open tension for future work).
