"""
CadetX Task 06 — Building the Prediction Model
Genre: AI Writing Tools | Products: Jasper, Copy.ai, Writesonic, Rytr

Input : data/processed/cadetx_task05_signal-level-features_v01.csv  (29 rows, Task 5)
        data/processed/cadetx_task05_product-level-features_v01.csv (4 rows, Task 5)
Output: reports/cadetx_task06_model-metrics_v01.md
        reports/cadetx_task06_signal-level-predictions_v01.csv
        reports/cadetx_task06_product-level-predicted-readiness_v01.csv
        models/cadetx_task06_logreg_model.joblib
        models/cadetx_task06_rf_model.joblib

--------------------------------------------------------------------------
WHAT "SUCCESS" MEANS HERE (read this before the metrics)
--------------------------------------------------------------------------
CadetX Task 6 asks the team to "define what success means for the genre"
and train a model on it. This dataset does not contain a genre-standard
launch-success outcome (e.g. revenue, retention, launch-day signup count) —
it contains individually-sourced public signals about 4 already-launched,
mature products. So "success" is operationalised at the level the data can
actually support:

    SIGNAL-LEVEL TARGET (`favorable_signal_label`, built in Task 5):
    whether an individual collected signal about a product reads as a
    favorable market/consumer signal (1) or an unfavorable one (0), using a
    documented, rule-based mapping of existing rating/sentiment/momentum/
    risk columns (see Task 5 feature dictionary). This is NOT "the product
    succeeded" — it is "this particular observed signal was favorable."

    PRODUCT-LEVEL READINESS SCORE (derived from the trained model): the
    mean predicted P(favorable) across all of a product's signals, i.e.
    "of everything we found about this product, how favorably does the
    model read it, on average?" This is the closest honest proxy to a
    genre-level launch-readiness read given 4 products.

--------------------------------------------------------------------------
WHY THERE IS NO CONVENTIONAL TRAIN/TEST SPLIT
--------------------------------------------------------------------------
n=29 signals (19 labelled) across 4 products is too small for a held-out
test set to mean anything (a single 80/20 split would test on ~4 rows).
Leave-One-Out Cross-Validation (LOOCV) is used instead: every row gets
exactly one out-of-sample prediction, using a model trained on all other
rows. This is the standard, honest choice for very small-n classification —
it is NOT a substitute for more data, and is disclosed as such throughout.
"""

import numpy as np
import pandas as pd
import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import LeaveOneOut
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    confusion_matrix,
)

SIGNAL_PATH = "data/processed/cadetx_task05_signal-level-features_v01.csv"
PRODUCT_PATH = "data/processed/cadetx_task05_product-level-features_v01.csv"

sig = pd.read_csv(SIGNAL_PATH)

# ---------------------------------------------------------------------------
# 1. Build modelling frame: drop unlabelled rows, select non-leaking features
# ---------------------------------------------------------------------------

labelled = sig[sig["favorable_signal_label"].notna()].copy()
n_excluded = len(sig) - len(labelled)

# Features that do NOT directly encode the label rule (avoids trivial
# leakage from rating/sentiment/momentum columns that built the label).
FEATURE_COLS = [
    "review_count_log1p",
    "engagement_total",
    "has_engagement",
    "is_comparative_signal",
    "is_discussion_thread",
    "is_editorial_review",
    "has_price_signal",
    "lexicon_sentiment_score",   # supplementary text signal, not the label trigger
    "has_rating",
    "has_review_count",
]
X = labelled[FEATURE_COLS].fillna(0).values
y = labelled["favorable_signal_label"].astype(int).values

print(f"Modelling frame: {len(labelled)} labelled rows ({n_excluded} excluded as ambiguous, see Task 5).")
print(f"Class balance: {y.sum()} favorable / {len(y) - y.sum()} unfavorable")

# ---------------------------------------------------------------------------
# 2. Leave-One-Out Cross-Validation for both models
# ---------------------------------------------------------------------------

loo = LeaveOneOut()

def loocv_predict_proba(model_ctor):
    proba = np.zeros(len(y))
    pred = np.zeros(len(y), dtype=int)
    for train_idx, test_idx in loo.split(X):
        m = model_ctor()
        m.fit(X[train_idx], y[train_idx])
        p = m.predict_proba(X[test_idx])[:, 1][0]
        proba[test_idx[0]] = p
        pred[test_idx[0]] = int(p >= 0.5)
    return proba, pred

logreg_ctor = lambda: LogisticRegression(max_iter=1000, C=1.0)
rf_ctor = lambda: RandomForestClassifier(n_estimators=200, max_depth=3, random_state=42)

logreg_proba, logreg_pred = loocv_predict_proba(logreg_ctor)
rf_proba, rf_pred = loocv_predict_proba(rf_ctor)

def metrics_block(y_true, y_pred, y_proba, name):
    return {
        "model": name,
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, y_proba) if len(set(y_true)) > 1 else float("nan"),
        "confusion_matrix": confusion_matrix(y_true, y_pred).tolist(),
    }

logreg_metrics = metrics_block(y, logreg_pred, logreg_proba, "LogisticRegression (LOOCV)")
rf_metrics = metrics_block(y, rf_pred, rf_proba, "RandomForest (LOOCV)")

for m in (logreg_metrics, rf_metrics):
    print(m)

# ---------------------------------------------------------------------------
# 3. Fit final models on ALL labelled data (for feature importance / scoring
#    future products) — separate from the LOOCV models used for evaluation.
# ---------------------------------------------------------------------------

final_logreg = logreg_ctor().fit(X, y)
final_rf = rf_ctor().fit(X, y)

coef_table = pd.DataFrame({
    "feature": FEATURE_COLS,
    "logreg_coefficient": final_logreg.coef_[0],
    "rf_importance": final_rf.feature_importances_,
}).sort_values("rf_importance", ascending=False)

joblib.dump(final_logreg, "models/cadetx_task06_logreg_model.joblib")
joblib.dump(final_rf, "models/cadetx_task06_rf_model.joblib")

# ---------------------------------------------------------------------------
# 4. Signal-level prediction export (LOOCV out-of-sample predictions)
# ---------------------------------------------------------------------------

labelled["logreg_loocv_proba"] = logreg_proba
labelled["logreg_loocv_pred"] = logreg_pred
labelled["rf_loocv_proba"] = rf_proba
labelled["rf_loocv_pred"] = rf_pred
labelled[[
    "signal_id", "product", "source_type", "favorable_signal_label",
    "logreg_loocv_proba", "logreg_loocv_pred", "rf_loocv_proba", "rf_loocv_pred",
]].to_csv("reports/cadetx_task06_signal-level-predictions_v01.csv", index=False)

# ---------------------------------------------------------------------------
# 5. Product-level readiness score: apply final models to ALL 29 signals
#    (including previously-excluded/ambiguous ones, since the model doesn't
#    need a label to score a row), then average per product.
# ---------------------------------------------------------------------------

X_all = sig[FEATURE_COLS].fillna(0).values
sig["logreg_proba_all"] = final_logreg.predict_proba(X_all)[:, 1]
sig["rf_proba_all"] = final_rf.predict_proba(X_all)[:, 1]

product_scores = sig.groupby("product").agg(
    n_signals=("signal_id", "count"),
    mean_logreg_readiness=("logreg_proba_all", "mean"),
    mean_rf_readiness=("rf_proba_all", "mean"),
).reset_index()
product_scores["mean_model_readiness"] = (
    product_scores["mean_logreg_readiness"] + product_scores["mean_rf_readiness"]
) / 2
product_scores = product_scores.sort_values("mean_model_readiness", ascending=False)
product_scores.to_csv("reports/cadetx_task06_product-level-predicted-readiness_v01.csv", index=False)

print("\nProduct-level predicted readiness (mean of both models' P(favorable)):")
print(product_scores.to_string(index=False))
print("\nFeature importance / coefficients:")
print(coef_table.to_string(index=False))
