# Task 6 — Building the Prediction Model (CadetX, AI Writing Tools genre)

## What's in this folder
```
data/processed/    Task 5 inputs (carried forward for traceability)
models/            Trained LogisticRegression + RandomForest (joblib), fit on all 19 labelled rows
reports/           THE ACTUAL DELIVERABLE:
  cadetx_task06_model-metrics_v01.md                    — target definition, LOOCV methodology, metrics, honest interpretation, feature importance, limitations
  cadetx_task06_signal-level-predictions_v01.csv        — LOOCV out-of-sample predictions, 19 rows
  cadetx_task06_product-level-predicted-readiness_v01.csv — 4-row business-facing readiness ranking
src/               cadetx_task06_prediction-model.py — reproducible script
```

## How to reproduce
```
pip install scikit-learn joblib pandas numpy --break-system-packages
python3 src/cadetx_task06_prediction-model.py
```

## Headline finding — read the metrics report, not just the accuracy number
Accuracy/F1 look fine (0.68–0.85) but **ROC-AUC is below 0.5 (0.19–0.26) for
both models** — on this small, imbalanced labelled set (19 rows, 14
favorable/5 unfavorable), neither model actually discriminates favorable
from unfavorable signals better than chance. This is reported as the
primary, honest modelling finding — see §4 of the metrics report for the
full explanation and why accuracy alone would have hidden it.
