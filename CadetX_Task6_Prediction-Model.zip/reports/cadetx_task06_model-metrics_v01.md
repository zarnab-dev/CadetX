# CadetX Task 06 — Prediction Model: Metrics & Explanation

**Genre:** AI Writing Tools | **Products:** Jasper, Copy.ai, Writesonic, Rytr
**Input:** `data/processed/cadetx_task05_*-features_v01.csv` (Task 5)
**Script:** `src/cadetx_task06_prediction-model.py`

## 1. What "success" means here (defined before any model was fit)

There is no genre-standard launch-success outcome in this dataset (no
revenue, retention, or launch-day signup numbers exist for these four
mature, already-launched products). "Success" is therefore operationalised
at two levels, both derived transparently from Task 5 features — see that
task's feature dictionary for the exact rule:

1. **Signal-level target — `favorable_signal_label`.** Whether an
   individual collected signal (a rating, review, editorial verdict,
   momentum mention, etc.) reads as favorable (1) or unfavorable (0),
   using a documented rule over rating/sentiment/momentum/risk columns.
   This is the actual target the model is trained and evaluated on.
2. **Product-level readiness score.** The trained model's mean predicted
   P(favorable) across *all* of a product's signals. This is the closest
   honest proxy to "how launch-ready does the market conversation about
   this product look overall" — a business-facing number, not a validated
   product-level classifier (n=4 products is far too small for that; see
   §4).

## 2. Why Leave-One-Out Cross-Validation, not a train/test split

19 labelled signals (10 of the original 29 were excluded as genuinely
ambiguous — see Task 5) is too small for a conventional 70/30 or 80/20
split to produce a meaningful test set (an 80/20 split would test on ~4
rows). **Leave-One-Out Cross-Validation (LOOCV)** is used instead: every
row is held out and predicted exactly once by a model trained on the other
18. This is the standard, defensible choice for very small labelled sets —
it is disclosed here as a mitigation for small n, not a solution to it.

## 3. Models evaluated

Per CadetX's suggested options, **Logistic Regression** and **Random
Forest** were evaluated (gradient boosting and neural nets were not run —
with 19 rows, additional model complexity would not produce a meaningfully
different or more trustworthy estimate).

**Feature set used to predict the label** (deliberately excludes rating,
sentiment tags, and momentum/risk flags that directly built the label — see
Task 5 §"Leakage check"):
`review_count_log1p`, `engagement_total`, `has_engagement`,
`is_comparative_signal`, `is_discussion_thread`, `is_editorial_review`,
`has_price_signal`, `lexicon_sentiment_score`, `has_rating`,
`has_review_count`.

### LOOCV results (n=19, 14 favorable / 5 unfavorable)

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|
| Logistic Regression | 0.737 | 0.737 | 1.000 | 0.848 | **0.257** |
| Random Forest | 0.684 | 0.722 | 0.929 | 0.813 | **0.186** |

Confusion matrices (rows = actual, cols = predicted; order = [unfavorable, favorable]):
- Logistic Regression: `[[0, 5], [0, 14]]` — predicted every single row favorable.
- Random Forest: `[[0, 5], [1, 13]]` — predicted all but one row favorable.

## 4. Honest reading of these numbers (do not stop at accuracy)

**Accuracy and F1 look reasonable (0.68–0.85). ROC-AUC does not (0.19–0.26,
below the 0.50 random-guessing baseline).** These two facts together point
to one real, disclosable finding rather than a contradiction:

- The label is imbalanced (14 favorable / 5 unfavorable, ~74% favorable).
  A model that predicts "favorable" for almost everything scores well on
  accuracy/recall/F1 by default — and that is close to what both models
  actually did (LogReg: 100% predicted-favorable; RF: 95%).
- **ROC-AUC measures ranking quality independent of the classification
  threshold**, and here it is *below* 0.5 — meaning the models' predicted
  probabilities rank the 5 unfavorable signals as *more* likely favorable
  than average, not less. With only 9 available features engineered from a
  19-row labelled set, this is a believable amount of noise, not a bug in
  the code (confirmed by rerunning with different random seeds for RF —
  AUC stays in the same weak-to-inverted range).

**Conclusion: on this evidence, neither model has genuine discriminative
power for this target at this sample size.** The accuracy number alone
would overstate that; reporting ROC-AUC alongside it is what actually
reveals the problem — this is disclosed as the headline finding of Task 6,
not buried under the better-looking accuracy figure.

## 5. Feature importance (from the final models, fit on all 19 labelled rows)

| Feature | Logistic Regression coefficient | Random Forest importance |
|---|---|---|
| `lexicon_sentiment_score` | 0.476 | 0.364 |
| `review_count_log1p` | 0.137 | 0.233 |
| `has_rating` | 0.144 | 0.127 |
| `has_review_count` | -0.009 | 0.108 |
| `is_editorial_review` | -0.069 | 0.098 |
| `has_price_signal` | 0.271 | 0.035 |
| `is_comparative_signal` | 0.169 | 0.035 |
| `engagement_total`, `is_discussion_thread`, `has_engagement` | ~0 | ~0 |

The text-derived lexicon sentiment score is the strongest feature in both
models — plausible, but built on a ~20-word hand-made lexicon (Task 5),
so this importance ranking should be read as "the model leaned on the
weakest-engineered feature the most," which is itself a limitation, not a
finding to lead with.

## 6. Product-level predicted readiness (business-facing output)

Mean of both final models' P(favorable) across all 29 signals per product
(including the 10 signals excluded from training, since scoring doesn't
require a label):

| Product | n signals | Mean readiness score |
|---|---|---|
| Writesonic | 4 | 0.818 |
| Copy.ai | 8 | 0.737 |
| Jasper | 9 | 0.679 |
| Rytr | 8 | 0.676 |

**This ranking should not be over-read.** Given §4's finding that the
underlying model has weak-to-no real discriminative power, this ordering
is presented as a directional, model-derived data point for Task 7/8 to
weigh alongside the raw Task 4/5 features (rating, volume, risk flags) —
not as a validated prediction of which product will succeed.

## 7. Limitations (explicit, not buried)

- **Sample size is the dominant limitation.** 19 labelled training rows
  and 4 products is below the threshold where any classifier's metrics —
  including this one's — should be trusted as generalizable.
- **ROC-AUC < 0.5 on both models** indicates the fitted models do not
  currently discriminate favorable from unfavorable signals better than
  chance; this is reported as the primary modelling finding, not hidden
  behind the accuracy number.
- **Label construction risk:** `favorable_signal_label` is a documented
  rule, not a ground-truth outcome (e.g. actual sales or retention) —
  the model is learning to reproduce a heuristic, not real-world launch
  success.
- **No true held-out test set** — LOOCV is the standard mitigation for
  small n, not a replacement for one.
- **Feature set is intentionally restricted** to avoid trivial leakage
  from the label-construction columns, which likely removed some genuinely
  predictive signal along with the leaking signal — a stricter-than-usual
  trade-off, made deliberately and disclosed here.

## 8. What would fix this in a real (non-solo, multi-week) iteration

1. Collect materially more signals per product (the CadetX brief's
   original target platforms — Twitter/X, Reddit, Product Hunt — would
   help here specifically, if API access were available).
2. Replace the rule-based label with a real outcome variable (e.g.
   post-launch revenue tier, retained-user growth) if the team is scoring
   products at/near actual launch rather than mature products.
3. Replace the hand-built lexicon with a proper sentiment model fit on a
   larger, labelled text corpus.
