# CadetX Task 03 — Data Cleaning & Preprocessing Notes

**Input:** `data/raw/cadetx_task02_raw_all-products_2026-09-08.csv` (29 rows)
**Output:** `data/cleaned/cadetx_task03_cleaned_all-products_v01.csv` (29 rows, 38 columns)
**Script:** `src/cadetx_task03_text-preprocessing.py`

## What was done

1. **De-duplication** — dropped exact duplicates on (`url`, `text_summary`).
   Result: 29 → 29 rows (no duplicates existed in this dataset).
2. **Timestamp normalisation** — `date_observed` values that weren't already
   in `YYYY-MM` / `YYYY-MM-DD` form (e.g. `"undated"`, `"2026 (live)"`) were
   set to `null` in `date_observed_clean` rather than guessed — several raw
   rows are genuinely undated (discussion threads, live aggregate pages), and
   inventing a date would misrepresent the data.
3. **Metric parsing** — the raw dataset stores compound fields
   (`metric_name`/`metric_value`, pipe-delimited, e.g.
   `"avg_rating|review_count"` / `"4.7|1269"`) because a single web source
   often reports more than one number. These were split into 21 individual
   `metric__*` columns (one per distinct metric name found across all rows),
   converted to numeric type where the value genuinely is a number, and left
   as text where it isn't (e.g. `"not stated (qualitative)"`,
   `"3000+"` — an inexact, source-reported figure kept as-is rather than
   rounded/invented). `avg_rating_numeric` and `review_count_numeric` are
   convenience aliases for the two most-used metrics.
4. **Text cleaning/NLP normalisation** applied to `text_summary` →
   `processed_text`:
   - lowercased
   - URLs stripped (`http…`/`www…`)
   - emoji ranges stripped (none were actually present in this dataset, but
     the step runs regardless so the pipeline is reusable on rawer social
     text later)
   - hashtags un-hashed (`#word` → `word`) — again a no-op here, kept for
     pipeline reuse
   - punctuation/special characters removed
   - tokenised on whitespace
   - stopwords removed (small built-in English stopword list — no external
     downloads, to keep the pipeline reproducible offline)
   - lightly stemmed (custom suffix stripper for `-ing/-edly/-ed/-ely/-es/-s`;
     **not** a full Porter stemmer — documented here rather than
     overclaiming accuracy)
5. **Engagement metrics → numeric** — `upvotes`/`comments` from G2 discussion
   threads were split out into `upvotes_numeric` / `comments_numeric`.

## Why this matters for Product Launch analysis

The cleaned, wide-format metric columns (`avg_rating_numeric`,
`review_count_numeric`, `upvotes_numeric`, `comments_numeric`) are what
Task 4 (EDA) and Task 5 (feature engineering) will aggregate per product —
e.g. mean rating per product, total review volume per product, thread
engagement per product. `processed_text` is retained for later keyword/
sentiment-adjacent analysis, understanding this dataset's text is our own
paraphrased summaries of sources (not raw social captions), so its
sentiment/theme signal is a proxy, not primary-source text mining — flagged
again in the Task 4 EDA report.

## Known limitations carried forward

- Sample size is small (29 rows across 4 products) because the underlying
  raw data is real, individually-sourced signals rather than a bulk API
  pull — precision of any aggregate stat computed from this is limited and
  will be stated as such in EDA/modelling, not hidden behind large N.
- Several metric fields are categorical/qualitative by nature (e.g.
  `editorial_verdict`, `sentiment`) and were correctly left non-numeric
  rather than force-encoded here; that encoding happens deliberately in
  Task 5 (feature engineering) with a documented mapping.
